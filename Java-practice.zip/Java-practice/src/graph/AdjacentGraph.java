package graph;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class AdjacentGraph {

    static LinkedList<Integer>[] adj;
    private int V, E;

    public AdjacentGraph(int node) {
        this.V = node;
        this.E = 0;
        this.adj = new LinkedList[node];
        for (int i = 0; i < node; i++) {
            this.adj[i] = new LinkedList<>();
        }
    }

    public void addEdge(int u, int v) {
        this.adj[u].add(v);
        this.adj[v].add(u);
        E++;
    }

    public static void main(String[] args) {

        AdjacentGraph g = new AdjacentGraph(7);
        g.addEdge(0, 1);
        g.addEdge(0, 2);
        g.addEdge(1, 3);
        g.addEdge(4, 5);
        g.addEdge(4, 6);
        printAdjList();
        g.bfs(0);
        System.out.println();
        g.dfs(0);

        System.out.println();
        g.dfs2(0);
    }

    public void bfs2(int n) {
        boolean[] visited = new boolean[V];
        Queue<Integer> queue = new LinkedList<>();
        visited[n] = true;
        queue.offer(n);
        while (!queue.isEmpty()) {

            int u = queue.poll();
            System.out.print(u);

            for (int v : adj[u]) {
                if (!visited[v]) {
                    visited[v] = true;
                    queue.offer(v);
                }
            }
        }
    }

    public void bfs(int n) {
        boolean[] visited = new boolean[V];
        Queue<Integer> q = new LinkedList<>();
        q.offer(n);
        visited[n] = true;
        while (!q.isEmpty()) {
            int u = q.poll();
            System.out.print(u + " ");
            for (int v : adj[u]) {

                if (!visited[v]) {
                    visited[v] = true;
                    q.offer(v);
                }
            }
        }
    }

    public void dfs2(int n) {

        boolean[] visited = new boolean[V];
        int connectedComp = 0;
        for (int i = 0; i < V; i++) {
            if (!visited[i]) {
                dfs2(i, visited);
                connectedComp++;
            }

        }

        System.out.println("No of connected components :: "+connectedComp);
    }

    public void dfs2(int i, boolean[] visited) {
        visited[i] = true;

        System.out.print(i);
        for (int u : adj[i]) {
            if (!visited[u])
                dfs2(u, visited);
        }
    }

    public void dfs(int n) {

        boolean[] visited = new boolean[V];
        Stack<Integer> stack = new Stack<>();
        stack.push(n);
        while (!stack.isEmpty()) {

            int k = stack.pop();
            if (!visited[k]) {
                visited[k] = true;
                System.out.print(k + " ");
                for (int v : adj[k]) {
                    if (!visited[v])
                        stack.push(v);
                }
            }
        }

    }

    public static void printAdjList() {
        for (int i = 0; i < adj.length; i++) {
            System.out.println(adj[i]);
        }
    }
}
