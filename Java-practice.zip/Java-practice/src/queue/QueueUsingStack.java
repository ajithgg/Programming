package queue;

import java.util.Stack;

public class QueueUsingStack {

    public static void main(String[] args) {

        QueueUsingStack queue=new QueueUsingStack();
        queue.add(1);
        queue.add(2);
        queue.add(3);
        queue.add(4);

        System.out.println(queue.size());

        for(int i=0;i<queue.size();i++){
            int removed= queue.remove();
            System.out.println(removed);
        }
    }

    Stack<Integer> first;
    Stack<Integer> second;

    public QueueUsingStack() {
        first = new Stack<>();
        second = new Stack<>();
    }

    public void add(int data) {
        first.push(data);
    }

    public int remove() {
        while (!first.isEmpty())
            second.push(first.pop());

        int removed = second.pop();

        while (!second.isEmpty())
            first.push(second.pop());

        return removed;
    }

    public boolean isEmpty(){
        return first.isEmpty();
    }

    public int size(){
        return first.size();
    }




}
