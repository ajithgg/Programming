package queue;

import java.util.Collections;
import java.util.PriorityQueue;

public class KlargestElement {

    public static void main(String[] args) {

        int nums[] = {6,5,4,3,2,1}; int k = 2;

        kLargestElement(nums,k);
    }

    public static void kLargestElement(int[] nums, int k){

        PriorityQueue queue=new PriorityQueue();
        System.out.println("Queue before :: "+queue);
        for(int i:nums){
            queue.offer(i);
        }


        System.out.println("Queue after :: "+queue);
    }
}
