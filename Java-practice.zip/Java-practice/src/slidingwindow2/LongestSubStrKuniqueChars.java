package slidingwindow2;

import java.util.HashMap;
import java.util.Map;

public class LongestSubStrKuniqueChars {

    public static void main(String[] args) {

        int maxSubStr = longestSubstr("aabacbebebef", 3);
        System.out.println(maxSubStr);

    }

    private static int longestSubstr(String str, int k) {

        int i = 0;
        int j = 0;
        Map<Character, Integer> map = new HashMap<>();
        char[] ch = str.toCharArray();
        int max = Integer.MIN_VALUE;
        while (j < ch.length) {

            map.put(ch[j], map.getOrDefault(ch[j], 0) + 1);

            if (map.size() < k) {
                j++;
            } else if (map.size() == k) {
                max = Math.max(max, j - i + 1);
                j++;
            } else if (map.size() > k) {

                while (map.size() > k) {
                    int c = map.get(ch[i]);
                    if (c == 1) {
                        map.remove(ch[i]);
                    } else {
                        map.put(ch[i], c--);
                    }
                    i++;
                }
                j++;
            }
        }

        return max;
    }
}
