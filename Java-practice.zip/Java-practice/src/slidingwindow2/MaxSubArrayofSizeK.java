package slidingwindow2;

public class MaxSubArrayofSizeK {

    public static void main(String[] args) {

        int[] a={1,2,-8,9,4,3,7};
        int maxSum=maxSumSubArray(a,3);

        System.out.println(maxSum);

    }


    private static int maxSumSubArray(int[] a,int k){
        int i=0;
        int j=0;
        int maxSum=Integer.MIN_VALUE;
        int sum=0;
        while(j<a.length){
            sum+=a[j];

            if(j-i+1<k){
                j++;
            }else if(j-i+1==k){
                maxSum=Math.max(maxSum,sum);
                sum-=a[i];
                j++;
                i++;
            }
        }
        return maxSum;
    }
}
