package slidingwindow2;

public class LargestSubArraySum {

    public static void main(String[] args) {
        int[] a={4,1,1,1,2,5,3,2};
        int m=largestSubArraySum(a,5);
        System.out.println("Largest sum array :: "+m);
    }

    private static int largestSubArraySum(int[] a, int k) {

        int sum = 0;
        int i = 0, j = 0;
        int max = Integer.MIN_VALUE;
        while (j < a.length) {
            sum += a[j];
            if (sum < k) {
                j++;
            } else if (sum == k) {
                sum-=a[i];
                max = Math.max(max, j - i + 1);
                j++;
                i++;
            }
        }
        return max;
    }
}
