package slidingwindow2;

import java.util.HashMap;
import java.util.Map;

public class MinimumWindow {

    public static void main(String[] args) {

        String str = minCharacterPAttern("this is a test string", "tist");
        System.out.println(str);

    }

    public static String minCharacterPAttern(String s, String pattern) {

        int i = 0;
        int j = 0;
        int minSize = Integer.MAX_VALUE;
        int start = 0;
        int end = 0;

        Map<Character, Integer> patternMap = new HashMap<>();
        char[] patArry = pattern.toCharArray();
        for (Character ch : patArry) {
            patternMap.put(ch, patternMap.getOrDefault(ch, 0) + 1);
        }
        int count = patternMap.size();


        while (j < s.length()) {

            /*Decrement the values in pattern map when char encountered in string*/
            if (patternMap.containsKey(s.charAt(j))) {
                patternMap.put(s.charAt(j), patternMap.get(s.charAt(j)) - 1);
                if (patternMap.get(s.charAt(j)) == 0)
                    count--;
            }


            if (count > 0) {

            } else {
                while (count == 0) {

                    if (minSize > j - i + 1) {
                        minSize = j - i + 1;
                        start = i;
                        end = j + 1;
                    }

                    if (patternMap.containsKey(s.charAt(i))) {

                        patternMap.put(s.charAt(i), patternMap.get(s.charAt(i))+1);
                        if (patternMap.get(s.charAt(i)) == 1)
                            count++;

                    }
                    i++;
                }
            }
            j++;
        }

        String str = s.substring(start, end);
        return str;
    }
}
