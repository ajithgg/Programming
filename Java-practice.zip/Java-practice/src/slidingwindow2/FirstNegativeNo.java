package slidingwindow2;

import java.util.ArrayList;
import java.util.List;

public class FirstNegativeNo {

    public static void main(String[] args) {
        int[] arr={1,-2,-3,4,6,-7,8,-9};
        int k=3;
        printFirstNegative(arr,k);

    }

    public static void printFirstNegative(int[] arr, int k) {

        int i = 0;
        int j = 0;
        List<Integer> ls = new ArrayList<>();
        while (i < arr.length) {

            if (arr[i] < 0)
                ls.add(arr[i]);

            if (j - i + 1 < k) {
                j++;
            } else if (j - i + 1 == k) {

                if (ls.size() > 0) {
                    System.out.print(ls.get(0)+" --> ");
                    ls.remove(ls.get(0));
                }
                j++;
                i++;
            }
        }
    }
}
