package binarysearch;

public class PeakElement {

    public static void main(String[] args) {

        //int a[]={1,10,15,8,9};
        int a[]={1,10,15,8,9};
        int i=mountainElement(a);
        System.out.println(i);

        String s="abca";

        String s2=s.substring(1,s.length());
        System.out.println(s2);

        System.out.println(s.contains("a"));

    }

    public static int mountainElement(int[] arr) {
        int low = 0;
        int high = arr.length - 1;
        while (high > low) {
            int mid = (high - low) / 2;

            if (arr[mid] > arr[mid + 1]) {
                high = mid;
            } else {
                low = mid + 1;
            }


        }

        return low;
    }
}
