package binarysearch;

public class NearlySortedArray {

    public static void main(String[] args) {

        int[] a = {10, 3, 40, 20, 50, 80, 70};
        int element = nearlyBs(a, 70, 0, a.length - 1);
        System.out.println(element);

    }

    public static int nearlyBs(int[] arr, int element, int start, int end) {

        int mid = (start + end) / 2;

        if (arr[mid] == element) {
            return mid;
        } else if (mid > start && arr[mid - 1] == element) {
            return mid - 1;
        } else if (mid < end && arr[mid + 1] == element) {
            return mid + 1;
        }

        if (arr[mid] > element)
            return nearlyBs(arr, element, start, mid - 2);
        else
            return nearlyBs(arr, element, mid + 2, end);
    }
}
