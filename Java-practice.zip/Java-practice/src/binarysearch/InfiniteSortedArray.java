package binarysearch;

public class InfiniteSortedArray {

    public static void main(String[] args) {

        int[] arr = { 3,   5,   7,   9,   10, 90,
                100, 130, 140, 160, 170 };
        int target=10;

        int ans=searchInInfiniteArray(arr,target);
        System.out.println(ans);

    }

    public static int searchInInfiniteArray(int[] a, int element) {

        int low = 0;
        int high = 1;

        while (element < a[high]) {
            low = high;
            high = high * 2;
        }

        while (low < high) {

            int mid = (low + high) / 2;

            if (a[mid] == element)
                return mid;
            else if (a[mid] < element) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }

        }


        return -1;
    }
}
