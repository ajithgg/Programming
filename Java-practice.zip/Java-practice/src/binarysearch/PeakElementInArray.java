package binarysearch;

public class PeakElementInArray {

    public static void main(String[] args) {

        int[] a = {5, 10, 20, 15};
        int paakElement = peakElement(a);
        System.out.println(paakElement);

    }

    public static int peakElement(int[] a) {

        int low = 0;
        int high = a.length - 1;

        while (low <= high) {

            int mid = (low + high) / 2;

            if ((mid == 0 || a[mid - 1] <= a[mid]) && (mid == a.length - 1 || a[mid + 1] <= a[mid])) {
                return mid;
            } else if (mid > 0 && a[mid - 1] > a[mid]) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }


        }


        return -1;
    }
}
