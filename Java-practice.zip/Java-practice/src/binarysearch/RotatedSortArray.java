package binarysearch;

public class RotatedSortArray {

    public static void main(String[] args) {


    }

    private int findRotateIndex(int[] a){
        int index=-1;

        int start=0;
        int end=a.length-1;
        int N=a.length;

        while(start<=end){

            int mid=start+(end-start)/2;
            int nextIdx=(mid+1)%N;
            int prevIdx=(mid+N-1)%N;

            if(a[mid]<a[nextIdx] && a[mid]<a[prevIdx]){
                //return
            }



        }


        return index;
    }
}
