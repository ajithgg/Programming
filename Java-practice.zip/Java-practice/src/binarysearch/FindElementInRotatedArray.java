package binarysearch;

public class FindElementInRotatedArray {

    public static void main(String[] args) {

        int[] arr={15, 18, 2, 3, 6, 12};

        System.out.println(findIndexInRotatedArray(arr,12));

    }

    public static int findIndexInRotatedArray(int[] a,int element){

        int start=0;
        int end=a.length-1;

        int minIdx=NoOfTimesArrayRotated.checkNumberOfTimesRotated(a);

        if(a[minIdx]==element){
            return minIdx;
        }else{

            int leftBs=binarySearch(a,start,minIdx-1,element);
            int rightBs=binarySearch(a,minIdx+1,end,element);

            if (leftBs != -1)
                return leftBs;
            else if (rightBs != -1)
                return rightBs;
            else return -1;
        }
    }

    public static int binarySearch(int[] a,int start,int end,int element){

        while (start<=end){

            int mid=(start+end)/2;
            if(a[mid]==element)
            {
                return mid;
            }else if(a[mid]>element){
                end=mid-1;
            }else{
                start=mid+1;
            }
        }

        return -1;
    }
}
