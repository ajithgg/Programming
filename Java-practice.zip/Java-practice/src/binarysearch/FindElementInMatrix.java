package binarysearch;

public class FindElementInMatrix {

    public static void main(String[] args) {

    }

    public static int findElementInSortedMatrix(int[][] a,int key){

        int i=0,n=a.length-1;
        int j=a[0].length-1;

        while(i>=0 && i<n && j>=0 && j<n){





        }



        return -1;
    }
}
