package binarysearch;

public class FirstLastOccurence {

    public static void main(String[] args) {

        int[] arr = {1, 3, 5, 5, 5, 5, 67, 123, 125};
        int resFirst = binarySearchFirst(arr, 5, 0, arr.length - 1);
        System.out.println(resFirst);
        int resLast = binarySearchLast(arr, 5, 0, arr.length - 1);
        System.out.println(resLast);

    }

    public static int binarySearchLast(int[] arr, int element, int start, int end) {
        int index = -1;
        while (start < end) {
            int mid = start + (end - start) / 2;

            if (arr[mid] == element) {
                index = mid;
                start = mid + 1;
            }else
            if (arr[mid] >= element) {
                end = mid - 1;
            } else {
                start = mid + 1;
            }


        }
        return index;
    }

    public static int binarySearchFirst(int[] arr, int element, int start, int end) {
        int index = -1;
        while (start < end) {
            int mid = start + (end - start) / 2;

            if (arr[mid] == element) {
                index = mid;
                end = mid - 1;
            }else
            if (arr[mid] < element) {
                start = mid + 1;
            } else {
                end = mid - 1;
            }


        }
        return index;
    }
}
