package binarysearch;

public class FindCielingElement {

    public static void main(String[] args) {

        int[] a={1, 2, 8, 10, 10, 12, 19};
        int floorElement=findCielingElement(a,11);
        System.out.println(floorElement);

    }

    public static int findCielingElement(int[] a, int element) {
        int start = 0, end = a.length - 1;


        int index = -1;

        while (start < end) {

            int mid = (start + end) / 2;

            if(a[mid]==element){
               return index=mid;
            }else
            if (a[mid] < element) {

                start = mid + 1;
            } else if (a[mid] > element) {
                index = mid;
                end = mid - 1;
            }
        }

        return index;
    }
}
