package binarysearch;

public class NoOfTimesArrayRotated {

    public static void main(String[] args) {

        int[] arr={15, 18, 2, 3, 6, 12};

        System.out.println(checkNumberOfTimesRotated(arr));

    }

    public static int checkNumberOfTimesRotated(int[] arr) {

        int start = 0;
        int end = arr.length - 1;
        int n = arr.length - 1;

        while (start <= end) {
            int mid = (start + end) / 2;
            int next = (mid + 1) % n;
            int prev = (mid + n - 1) % n;

            if (arr[mid] <= arr[prev] && arr[mid] <= arr[next]) {
                return mid;
            } else if (arr[start] <= arr[mid]) {
                start = mid + 1;
            } else if (arr[mid] <= arr[end]) {
                end = mid - 1;
            }
        }

        return -1;
    }
}
