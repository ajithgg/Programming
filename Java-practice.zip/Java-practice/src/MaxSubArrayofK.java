import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MaxSubArrayofK {

    public static void main(String[] args) {

        List ls= Arrays.asList(100, 200, 300, 400);
        long maxSum=maximumSumSubarray(2,ls,ls.size());

        System.out.println(maxSum);

    }
    static long maximumSumSubarray(int K, List<Integer> Arr, int N) {
        // code here
        int i = 0;
        int j = 0;
        int max = 0;
        int sum = 0;

        List ls=new ArrayList();
        while (j < Arr.size()) {
            sum += Arr.get(j);

            if (j - i + 1 < K) {
                j++;
            } else if (j - i + 1 == K) {
                max = Math.max(sum, max);

                ls.stream().findFirst();
                sum -= Arr.get(i);
                j++;
                i++;
            }

        }
        return max;
    }
}
