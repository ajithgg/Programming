package binarytree;

import java.util.Stack;

public class BtreeIterative {

    private static Node head;

    static class Node {

        Node left, right = null;
        int data;

        Node(int data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    private static void createBinaryTree() {
        Node first = new Node(1);
        Node second = new Node(2);
        Node third = new Node(3);
        Node fourth = new Node(4);
        Node fifth = new Node(5);
        Node sixth = new Node(6);
        Node seventh = new Node(7);
        Node eight = new Node(8);

        head = first;
        first.left = second;
        first.right = third;

        second.left = fourth;
        second.right = fifth;

        third.left = sixth;
        third.right = seventh;

        fourth.left = eight;
    }

    private static void preOrderIterative(Node node) {

        if (node == null)
            return;

        Stack<Node> stack = new Stack<>();
        stack.push(head);
        while (!stack.isEmpty()) {

            Node temp = stack.pop();

            System.out.print(temp.data+" -> ");
            if (temp.right != null) {
                stack.push(temp.right);
            }

            if (temp.left != null) {
                stack.push(temp.left);
            }
        }

    }

    public static void main(String[] args) {

        createBinaryTree();
        preOrderIterative(head);

    }
}
