package binarytree;

import java.util.Stack;

public class PostBtree {

    private static Node head;

    static class Node {

        Node left, right = null;
        int data;

        Node(int data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }

    }

    private static void createBinaryTree() {
        PostBtree.Node first = new PostBtree.Node(1);
        PostBtree.Node second = new PostBtree.Node(2);
        PostBtree.Node third = new PostBtree.Node(3);
        PostBtree.Node fourth = new PostBtree.Node(4);
        PostBtree.Node fifth = new PostBtree.Node(5);
        PostBtree.Node sixth = new PostBtree.Node(6);
        PostBtree.Node seventh = new PostBtree.Node(7);
        PostBtree.Node eight = new PostBtree.Node(8);

        head = first;
        first.left = second;
        first.right = third;

        second.left = fourth;
        second.right = fifth;

        third.left = sixth;
        third.right = seventh;

        fourth.left = eight;
    }

    public static void postOrderIterative(Node head){

        if(head==null)
            return;

        Stack<Node> stack=new Stack<>();
        stack.push(head.left);

        while(!stack.isEmpty()){

            Node current=stack.pop();

            //if(current.)
            System.out.print(current.data+" -> ");



        }


    }

    public static void postOrderRecursive(Node head){

        if(head==null)
            return;

        postOrderRecursive(head.left);
        postOrderRecursive(head.right);
        System.out.print(head.data +" -> ");
    }

    public static void main(String[] args) {


        createBinaryTree();

        postOrderRecursive(head);
    }
}
