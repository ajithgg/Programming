package binarytree;

public class BinaryTree {

    private static Node head;

    static class Node {

        Node left, right = null;
        int data;

        Node(int data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    private static void createBinaryTree() {
        Node first = new Node(1);
        Node second = new Node(2);
        Node third = new Node(3);
        Node fourth = new Node(4);
        Node fifth = new Node(5);
        Node sixth = new Node(6);
        Node seventh = new Node(7);
        Node eight = new Node(8);

        head = first;
        first.left = second;
        first.right = third;

        second.left = fourth;
        second.right = fifth;

        third.left = sixth;
        third.right = seventh;

        fourth.left = eight;
    }

    public static void preOrder(Node node) {

        if (node == null)
            return;

        System.out.print(node.data + " -> ");
        preOrder(node.left);
        preOrder(node.right);
    }

    public static void main(String[] args) {

        createBinaryTree();
        preOrder(head);

    }


}
