package binarytree;

import java.util.LinkedList;
import java.util.Queue;

public class BtreeTraversal {

    private static Node head;

    static class Node {

        int data;
        Node left, right;

        Node(int data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    public static void leftViewTraversal(Node root) {

        if (root == null)
            return;

        Queue<Node> queue = new LinkedList<>();
        queue.add(root);

        while (!queue.isEmpty()) {

            int n = queue.size();

            for (int i = 0; i < n; i++) {

                Node temp = queue.remove();

                if (i == 0) {
                    System.out.print(temp.data + " -> ");
                }

                if (temp.left != null)
                    queue.add(temp.left);

                if (temp.right != null)
                    queue.add(temp.right);

            }
        }


    }

    public static void rightViewTraversal(Node root) {

        if (root == null)
            return;

        Queue<Node> queue = new LinkedList<>();
        queue.add(root);

        while (!queue.isEmpty()) {

            int n = queue.size();

            for (int i = 0; i < n; i++) {

                Node temp = queue.remove();

                if (i == 0) {
                    System.out.print(temp.data + " -> ");
                }

                if (temp.right != null)
                    queue.add(temp.right);

                if (temp.left != null)
                    queue.add(temp.left);

            }
        }
    }

    public static void main(String[] args) {

        Node first = new Node(1);
        Node second = new Node(2);
        Node third = new Node(3);
        Node fourth = new Node(4);
        Node fifth = new Node(5);
        Node sixth = new Node(6);
        Node seventh = new Node(7);
        Node eight = new Node(8);
        Node ninth = new Node(9);

        head = first;
        first.left = second;
        first.right = third;

        second.left = fourth;
        second.right = fifth;

        third.left = sixth;
        third.right = seventh;

        fourth.left = eight;
        fourth.right = ninth;

        //rightViewTraversal(head);
        leftViewTraversal(head);

    }
}
