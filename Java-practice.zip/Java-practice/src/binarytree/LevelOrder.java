package binarytree;

import java.util.*;

public class LevelOrder {

    private static Node head;

    static class Node {

        Node left, right = null;
        int data;

        Node(int data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    public static void levelOrderTraverse(Node head) {

        Queue<Node> queue = new LinkedList<>();

        queue.offer(head);
        queue.offer(null);

        while (!queue.isEmpty()) {

            Node current = queue.remove();
            if (current == null) {
                System.out.println();
                if (queue.isEmpty()) {
                    break;
                } else {
                    queue.add(null);

                }

            } else {
                System.out.print(current.data + " ");
                if (current.left != null)
                    queue.add(current.left);

                if (current.right != null)
                    queue.add(current.right);
            }
        }

    }

    public static void levelOrderTraversal(Node head) {

        Queue<Node> queue = new LinkedList<>();

        queue.offer(head);
        while (!queue.isEmpty()) {
            Node temp = queue.poll();

            System.out.print(temp.data);
            if (temp.left != null)
                queue.offer(temp.left);

            if (temp.right != null)
                queue.offer(temp.right);
        }


    }

    public static void zigzagTraversalUsingQueue(Node root){

        List<Integer> res=new ArrayList<>();
        if(root==null)
            return;

        Queue<Node> q=new LinkedList<>();

        q.add(root);
        boolean leftToRight=true;

        while (!q.isEmpty()){

            int size=q.size();
            int[] temp=new int[size];

            for (int i = 0; i < size; i++) {

                Node front=q.poll();
                int index=leftToRight?i:size-i-1;
                temp[index]=front.data;

                if(front.left!=null)
                    q.add(front.left);

                if(front.right!=null)
                    q.add(front.right);
            }

            leftToRight=!leftToRight;

            for(int k:temp)
                res.add(k);
        }

        System.out.println(res);
    }

    public static void zigzagTraversal(Node root) {

        if (root == null)
            return;

        Stack<Node> currentLevel = new Stack<>();
        Stack<Node> nextLevel = new Stack<>();

        boolean leftToRight = true;

        currentLevel.push(root);

        while (!currentLevel.isEmpty()) {

            Node temp = currentLevel.pop();

            if (null != temp) {

                System.out.print(temp.data+" -> ");


                if (leftToRight) {
                    if (temp.left != null)
                        nextLevel.push(temp.left);

                    if (temp.right != null)
                        nextLevel.push(temp.right);

                } else {
                    if (temp.right != null)
                        nextLevel.push(temp.right);

                    if (temp.left != null)
                        nextLevel.push(temp.left);
                }

            }

            if (currentLevel.isEmpty()) {
                leftToRight = !leftToRight;

                Stack<Node> tempNode = currentLevel;
                currentLevel = nextLevel;
                nextLevel = tempNode;
            }


        }


    }

    public static void swap(Stack<Node> currentLevel, Stack<Node> nextLevel) {
        Stack<Node> temp = currentLevel;
        currentLevel = nextLevel;
        nextLevel = temp;
    }

    private static void createBinaryTree() {
        LevelOrder.Node first = new LevelOrder.Node(1);
        LevelOrder.Node second = new LevelOrder.Node(2);
        LevelOrder.Node third = new LevelOrder.Node(3);
        LevelOrder.Node fourth = new LevelOrder.Node(4);
        LevelOrder.Node fifth = new LevelOrder.Node(5);
        LevelOrder.Node sixth = new LevelOrder.Node(6);
        LevelOrder.Node seventh = new LevelOrder.Node(7);
        LevelOrder.Node eight = new LevelOrder.Node(8);
        LevelOrder.Node ninth = new LevelOrder.Node(9);

        head = first;
        first.left = second;
        first.right = third;

        second.left = fourth;
        second.right = fifth;

        third.left = sixth;
        third.right = seventh;

        fourth.left = eight;
        fourth.right=ninth;

    }

    public static void main(String[] args) {
        createBinaryTree();
        //levelOrderTraversal(head);
        //levelOrderTraverse(head);

        //zigzagTraversal(head);

        zigzagTraversalUsingQueue(head);
    }
}
