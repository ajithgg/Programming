package binarytree;

import java.util.*;

public class BtreeSample {

    private static Node head;

    static class Node {

        int data;
        BtreeSample.Node left, right;

        Node(int data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    public static int maxDepth(Node root) {

        if (root == null)
            return 0;

        int lh = maxDepth(root.left);
        int rh = maxDepth(root.right);

        return (lh + rh) + 1;
    }

    public static int height(Node root) {

        if (root == null)
            return 0;

        int lh = height(root.left);
        int rh = height(root.right);

        return Math.max(lh, rh) + 1;
    }

    public static boolean isBalanced(Node root) {

        if (root == null)
            return true;


        if (!isBalanced(root.left))
            return false;

        if (!isBalanced(root.right))
            return false;

        int lh = height(root.left);
        int rh = height(root.right);

        if (Math.abs(lh - rh) <= 1) {
            return true;
        } else {
            return false;
        }
    }

    public static void boundaryTraversal(Node root) {

        List<Integer> dataList = new ArrayList<>();
        if (isLeaf(root) == false)
            dataList.add(root.data);

        addLeftBoundary(root.left, dataList);
        addLeaves(root, dataList);
        addRightBoundary(root.right, dataList);

        dataList.forEach(x -> {
            System.out.print(x + " -> ");
        });

    }

    private static void addLeaves(Node root, List<Integer> dataList) {

        if (isLeaf(root)) {
            dataList.add(root.data);
            return;
        }

        if (root.left != null)
            addLeaves(root.left, dataList);

        if (root.right != null)
            addLeaves(root.right, dataList);
    }

    private static void addLeftBoundary(Node root, List<Integer> dataList) {

        Node curr = root;
        while (curr != null) {
            if (!isLeaf(curr))
                dataList.add(curr.data);

            if (curr.left != null)
                curr = curr.left;
            else
                curr = curr.right;
        }
    }

    private static void displayLeftView(Node root){

        List<Node> leftViewList=leftView(root,0,new ArrayList<>());
        leftViewList.forEach(x->{
            System.out.print(x.data + " -> ");
        });
    }

    private static void displayRightView(Node root){

        List<Node> rithViewList=leftView(root,0,new ArrayList<>());
        rithViewList.forEach(x->{
            System.out.print(x.data + " -> ");
        });
    }

    private static List<Node> leftView(Node root,int level,List<Node> nodeList){

        if(root==null)
            return nodeList;

        if(level==nodeList.size())
            nodeList.add(root);

        leftView(root.right,level+1,nodeList);
        leftView(root.left,level+1,nodeList);


        return nodeList;
    }

    private static List<Node> rightView(Node root,int level,List<Node> nodeList){

        if(root==null)
            return nodeList;

        if(level==nodeList.size())
            nodeList.add(root);

        rightView(root.right,level+1,nodeList);
        rightView(root.left,level+1,nodeList);


        return nodeList;
    }

    private static void addRightBoundary(Node root, List<Integer> dataList) {

        Node curr = root;
        List<Integer> temp = new ArrayList<>();

        while (curr != null) {

            if (!isLeaf(curr))
                temp.add(curr.data);

            if (curr.right != null)
                curr = curr.right;
            else curr = curr.left;
        }

        for (int i = temp.size() - 1; i >= 0; i--) {
            dataList.add(temp.get(i));
        }
    }

    public static boolean isLeaf(Node node) {
        if (node.left == null && node.right == null)
            return true;
        return false;
    }


    public static void main(String[] args) {

        BtreeSample.Node first = new BtreeSample.Node(1);
        BtreeSample.Node second = new BtreeSample.Node(2);
        BtreeSample.Node third = new BtreeSample.Node(3);
        BtreeSample.Node fourth = new BtreeSample.Node(4);
        BtreeSample.Node fifth = new BtreeSample.Node(5);
        BtreeSample.Node sixth = new BtreeSample.Node(6);
        BtreeSample.Node seventh = new BtreeSample.Node(7);
        BtreeSample.Node eight = new BtreeSample.Node(8);
        BtreeSample.Node ninth = new BtreeSample.Node(9);

        head = first;
        first.left = second;
        first.right = third;

        second.left = fourth;
        second.right = fifth;

        third.left = sixth;
        third.right = seventh;

        fourth.left = eight;
        fourth.right = ninth;

        //int maxDepth=maxDepth(head);
        //System.out.println(maxDepth);
        //System.out.println(isBalanced(head));

        //boundaryTraversal(head);

        //bottomView(head);

        //topView(head);

        displayRightView(head);
        System.out.println();
        displayLeftView(head);

    }

    public static List<Integer> topView(Node root) {

        List<Integer> ans = new ArrayList<>();

        if (root == null)
            return ans;

        Map<Integer, Integer> map = new TreeMap<>();
        Queue<Pair> queue = new LinkedList<>();
        queue.add(new Pair(root, 0));

        while (!queue.isEmpty()) {

            Pair it = queue.remove();
            int hd = it.hd;

            Node temp = it.node;

            if (map.get(hd) == null)
                map.put(hd, temp.data);

            if (temp.left != null)
                queue.add(new Pair(temp.left, hd - 1));

            if (temp.right != null)
                queue.add(new Pair(temp.right, hd + 1));
        }


        for (Map.Entry<Integer, Integer> m : map.entrySet()) {
            ans.add(m.getValue());
            System.out.print(m.getValue());
        }

        return ans;
    }

    public static List<Integer> topView2(Node root){

        List<Integer> ans=new ArrayList<>();

        if(root==null)
            return ans;

        Map<Integer,Integer> map=new TreeMap<>();
        Queue<Pair> queue=new LinkedList<>();
        queue.add(new Pair(root,0));

        while (!queue.isEmpty()){

            Pair pair=queue.remove();

            int it=pair.hd;
            Node temp=pair.node;

            if(map.get(it)==null)
                map.put(it,temp.data);

            if(temp.left!=null)
                queue.add(new Pair(temp.left,it-1));

            if(temp.right!=null)
                queue.add(new Pair(temp.right,it+1));

        }

        for (Map.Entry<Integer, Integer> m : map.entrySet()) {
            ans.add(m.getValue());
            System.out.print(m.getValue());
        }

        return ans;
    }

    private static void bottomView(Node root) {

        List<Integer> ans = new ArrayList<>();

        if (root == null)
            return;

        Map<Integer, Integer> map = new TreeMap<>();
        Queue<Pair> queue = new LinkedList<>();
        queue.add(new Pair(root, 0));

        while (!queue.isEmpty()) {

            Pair t = queue.remove();
            int hd = t.hd;

            Node temp = t.node;
            map.put(hd, temp.data);

            if (temp.left != null)
                queue.add(new Pair(temp.left, hd - 1));

            if (temp.right != null)
                queue.add(new Pair(temp.right, hd + 1));


        }

        for (Map.Entry<Integer, Integer> m : map.entrySet()) {
            ans.add(m.getValue());
            System.out.print(m.getValue()+ " -> ");
        }


    }

    public static void bottomView2(Node root){

        List<Integer> ans=new ArrayList<>();

        if(root==null)
            return;

        Queue<Pair> queue=new LinkedList<>();
        Map<Integer,Integer> map=new TreeMap<>();

        queue.add(new Pair(root,0));

        while (!queue.isEmpty()){

            Pair pair=queue.remove();

            int it=pair.hd;
            Node temp=pair.node;

            map.put(it,temp.data);

            if(temp.left!=null)
                queue.add(new Pair(temp.left,it-1));

            if(temp.right!=null)
                queue.add(new Pair(temp.right,it+1));

        }

        for (Map.Entry<Integer, Integer> m : map.entrySet()) {
            ans.add(m.getValue());
            System.out.print(m.getValue()+ " -> ");
        }
    }

    static class Pair {

        Node node;
        int hd;

        Pair(Node node, int hd) {
            this.node = node;
            this.hd = hd;
        }
    }
}
