package binarytree;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class InOrderTraversal {

    private static Node head;

    static class Node {

        Node left, right = null;
        int data;

        Node(int data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    private static void createBinaryTree() {
        Node first = new Node(1);
        Node second = new Node(2);
        Node third = new Node(3);
        Node fourth = new Node(4);
        Node fifth = new Node(5);
        Node sixth = new Node(6);
        Node seventh = new Node(7);
        Node eight = new Node(8);

        head = first;
        first.left = second;
        first.right = third;

        second.left = fourth;
        second.right = fifth;

        third.left = sixth;
        third.right = seventh;

        fourth.left = eight;
    }

    private static void inOrderIterative(
            Node node) {
        //left -> root -> right
        if (node == null)
            return;

        Stack<Node> stack = new Stack<>();
        List<Integer> ls = new ArrayList<>();

        Node current = node;

        while (true) {

            if (current != null) {
                stack.push(current);
                current = current.left;

            } else {
                if (stack.isEmpty())
                    break;

                current = stack.pop();
                System.out.print(current.data + " -> ");
                current = current.right;

            }
        }
    }

    private static void inOrderTraversal(Node node) {

        if (node == null)
            return;

        inOrderTraversal(node.left);
        System.out.print(node.data + " -> ");
        inOrderTraversal(node.right);
    }

    public static void main(String[] args) {

        createBinaryTree();
        //inOrderTraversal(head);
        inOrderIterative(head);

    }
}
