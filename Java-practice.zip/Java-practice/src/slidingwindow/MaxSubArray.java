package slidingwindow;

public class MaxSubArray {

    public static void main(String[] args) {

        int[] arr = {3, 2, 4, 1, 6, 7, 0, 8};


        int maxSum = findMaxSubArraySum(arr, 3);
        int maxSum2 = findMaxUsingWindow(arr,3);
        System.out.println(maxSum);

        System.out.println(maxSum2);
    }

    private static int findMaxSubArraySum(int[] arr, int k) {
        int maxSum = Integer.MIN_VALUE;
        for (int i = 0; i < arr.length; i++) {
            int currSum = 0;
            for (int j = i; j < i + k && j < arr.length; j++) {
                currSum += arr[j];
            }
            maxSum = Math.max(maxSum, currSum);
        }
        return maxSum;
    }

    private static int findMaxUsingWindow(int[] arr, int k) {
        int maxSum = Integer.MIN_VALUE;
        int i = 0;
        int j = 0;
        int sum = 0;
        while (j < arr.length) {
            sum = sum + arr[j];

            if (j - i + 1 < k) {
                j++;
            } else if (j - i + 1 == k) {
                maxSum = Math.max(sum, maxSum);
                sum-=arr[i];
                j++;
                i++;
            }
        }
        return maxSum;
    }
}
