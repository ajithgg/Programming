package slidingwindow;

import java.util.HashMap;
import java.util.Map;

public class LongestKUniqueCharactersSubstring {

    public static void main(String[] args) {

        String s1="abc";
        String s2="abc";
        s2.concat("d");

        System.out.println(s1==s2);
        System.out.println(s1.equals(s2));
        //int out = longestSubString("aaabb", 2);
        //System.out.println(out);
    }

    private static int longestSubString(String str, int k) {

        int i = 0;
        int j = 0;
        char[] ch = str.toCharArray();
        Map<Character, Integer> mp = new HashMap<>();
        int maxSize = Integer.MIN_VALUE;
        int currSize = 0;
        while (j < ch.length) {
            mp.put(ch[j], mp.getOrDefault(ch[j], 0) + 1);

            if (mp.size() < k) {
                j++;
            } else if (mp.size() == k) {
                currSize = j - i + 1;
                maxSize = Math.max(maxSize, currSize);
                j++;

            } else {

                mp.put(ch[j], mp.get(ch[j]) - 1);
                if (mp.get(ch[j]) == 0) {
                    mp.remove(ch[j]);
                }


            }

        }


        return maxSize;
    }
}
