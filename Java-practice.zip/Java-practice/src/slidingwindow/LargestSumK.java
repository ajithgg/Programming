package slidingwindow;

public class LargestSumK {

    public static void main(String[] args) {

        int[] arr={4,1,1,1,2,3,5};
        int maxSizeArr=findLargestSumSubArray(arr,5);
        System.out.println(maxSizeArr);
        System.out.println("---------------------");
        int maxSizeArr2=findLargestSumSubArrayWindow(arr,5);
        System.out.println(maxSizeArr2);
    }

    private static int findLargestSumSubArrayWindow(int[] arr,int k){
        int maxSizeArr=Integer.MIN_VALUE;

        int i=0,j=0;
        int sum=0;
        while(j<arr.length){

             sum+=arr[j];

            if(sum<k){
                j++;
            }else if(sum==k){

                int currWindow=j-i+1;
                maxSizeArr=Math.max(currWindow,maxSizeArr);
                j++;
                i++;
                sum=0;
            }


        }

        return maxSizeArr;
    }

    private static int findLargestSumSubArray(int[] arr,int k){

        int maxSizeArr=Integer.MIN_VALUE;

        for(int i=0;i<arr.length;i++){
            int sum=0;
            for(int j=i;j<arr.length;j++){
                sum+=arr[j];
                if(sum==k){
                    int currSubArrSize=j-i+1;
                    maxSizeArr=Math.max(currSubArrSize,maxSizeArr);
                }
            }
        }
        return maxSizeArr;
    }
}
