package slidingwindow;

import java.util.HashMap;
import java.util.Map;

public class LargestNonRepeatingChar {

    public static void main(String[] args) {

        int maxLength = largesNonRepeatingChar("pwwkew");
        System.out.println("------ maxLength ----- " + maxLength);
        int maxLength2 = largestNonRepeatingSlidingWindow("pwwkew");
        System.out.println("------ maxLength2 ----- " + maxLength2);
    }

    private static int largestNonRepeatingSlidingWindow(String str) {

        int maxLength = Integer.MIN_VALUE;
        char[] ch = str.toCharArray();
        Map<Character, Integer> mp = new HashMap<>();
        int i = 0, j = 0;
        while (j < ch.length) {

            mp.put(ch[j], mp.getOrDefault(ch[j], 0) + 1);

            if (mp.size() == j - i + 1) {
                maxLength=Math.max(maxLength,j-i+1);
                j++;
            } else if (mp.size() < j - i + 1) {
                while (mp.size() < j - i + 1) {
                    mp.put(ch[i], mp.get(ch[i]) - 1);
                    if (mp.get(ch[i]) == 0) {
                        mp.remove(ch[i]);
                    }
                    i++;
                }
                j++;
            }

        }

        return maxLength;
    }

    private static int largesNonRepeatingChar(String str) {
        //abcdaabbbcdfgh

        String strVal = "";
        int maxLength = Integer.MIN_VALUE;

        char[] ch = str.toCharArray();

        for (int i = 0; i < ch.length; i++) {

            if (!strVal.contains(String.valueOf(ch[i]))) {
                strVal = strVal.concat(String.valueOf(ch[i]));
            } else {
                maxLength = Math.max(maxLength, strVal.length());
                strVal = "";
            }
        }
        return Math.max(maxLength, strVal.length());
    }
}
