package slidingwindow;

import java.util.ArrayList;
import java.util.List;

public class FirstNegativeNumber {

    public static void main(String[] args) {

        int[] arr = {-3, 2, 1, 0, -5, -6, 2, -8, -7, -3};
        printNegativeNum(arr, 3);
        System.out.println("-------------------------------");
        printNegativeNoUsingSlidingWindow(arr, 3);

    }

    private static void printNegativeNum(int[] arr, int k) {

        for (int i = 0; i < arr.length; i++) {

            for (int j = i; j < i + k && j < arr.length; j++) {

                if (arr[j] < 0) {
                    System.out.print(arr[j] + " ");
                    break;
                }
            }
        }
    }

    private static void printNegativeNoUsingSlidingWindow(int[] arr, int k) {

        int i = 0;
        int j = 0;
        List<Integer> dataList = new ArrayList<>();

        while (j < arr.length) {

            if (arr[j] < 0) {
                dataList.add(arr[j]);
            }

            if (j - i + 1 < k) {
                j++;
            } else if (j - i + 1 == k) {
                if (!dataList.isEmpty()) {
                    System.out.print(dataList.get(0) + " ");
                    if (dataList.get(0) == arr[i]) {
                        dataList.remove(0);
                    }
                }
                j++;
                i++;
            }
        }

    }
}
