package slidingwindow;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class CountAnagramOccurence {

    public static void main(String[] args) {

        int count = checkAnagramsPresent("forabcdrofijklorf", "for");

        System.out.println(count);
        System.out.println("----------------------");
        int count2=countAnagramsWindow("forabcdrofijklorf", "for");
        System.out.println(count2);
    }

    public static boolean isAnagram(String s1, String s2) {
        char[] c1 = s1.toCharArray();
        char[] c2 = s2.toCharArray();
        Arrays.sort(c1);
        Arrays.sort(c2);

        if (Arrays.equals(c1, c2)) {
            return true;
        } else {
            return false;
        }
    }

    public static int countAnagramsWindow(String s1, String s2) {

        int i = 0;
        int j = 0;
        int k = s2.length();
        Set<String> freqSet = new HashSet<>();

        while (j < s1.length()) {

            if (j - i + 1 < k) {
                j++;
            } else if (j - i + 1 == k) {

                String subStr = s1.substring(i, j+1);
                if (isAnagram(subStr, s2)) {
                    freqSet.add(subStr);
                }
                j++;
                i++;
            }
        }

        System.out.println(freqSet);
        return freqSet.size();
    }

    public static int checkAnagramsPresent(String s1, String s2) {

        char[] c = s1.toCharArray();
        Set<String> freqSet = new HashSet<>();
        for (int i = 0; i < c.length; i++) {

            if (i + s2.length() <= s1.length()) {
                String subStr = s1.substring(i, i + s2.length());

                boolean checkAnagram = isAnagram(s2, subStr);
                if (checkAnagram) {
                    freqSet.add(subStr);
                }
            }
        }

        System.out.println(freqSet);
        return freqSet.size();
    }
}
