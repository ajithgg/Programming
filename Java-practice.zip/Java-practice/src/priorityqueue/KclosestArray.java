package priorityqueue;

import java.util.*;

class Pair{

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }

    @Override
    public String toString() {
        return "Pair{" +
                "key=" + key +
                ", value=" + value +
                '}';
    }

    Integer key;
    Integer value;

    public Pair(Integer key,Integer value) {
        this.key = key;
        this.value=value;
    }
}

public class KclosestArray {



    public static void main(String[] args) {
        int[] a={10, 2, 14, 4, 7, 6};
         int x = 5, k = 3 ;
        kClosestArray(a,k,x);

    }

    private  static void kClosestArray(int[] a,int k,int x){

        List<Pair> pairList = new ArrayList<>();
        PriorityQueue pQueue = new PriorityQueue(new Comparator<Pair>() {

            public int compare(Pair o1, Pair o2) {
                return o1.getKey().compareTo(
                        o2.getKey()
                );
            }
        });

        for(int i:a){
            //System.out.println(i);
            int m=i;
            pQueue.offer(new Pair(Math.abs(i-x),m));

            if(pQueue.size()>k){
                System.out.println("*************");
                Pair p= (Pair) pQueue.poll();
                System.out.println(p);
                pairList.add(p);
            }
        }

        for(Pair p:pairList){
            System.out.print(p.value+" - ");
        }
    }
}
