package priorityqueue;

import java.util.PriorityQueue;

public class KlargestElement {

    public static void main(String[] args) {
        int[] a={5,7,2,3,1,9,8};
        System.out.println(getLargestElement(a,3));

    }

    private static int getLargestElement(int[] a,int k){

        PriorityQueue queue=new PriorityQueue();

        for(int i=0;i<a.length;i++){

            queue.offer(a[i]);

            if(queue.size()>k){
                queue.poll();
            }
        }

        int larges=Integer.parseInt(queue.poll().toString());
         return larges;
    }
}
