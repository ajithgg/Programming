package priorityqueue;

import java.util.PriorityQueue;

public class KsortedArray {

    public static void main(String[] args) {

        int k = 3;
        int arr[] = { 2, 6, 3, 12, 56, 8 };
        int n = arr.length;

        sortKelements(arr,k);

    }

    private static void sortKelements(int[] a,int k){

        int[] b=new int[k];
        PriorityQueue queue=new PriorityQueue();
        int l=0;
        for(int i:a){

            queue.offer(i);

            if(queue.size()>k){
                b[l]=Integer.parseInt(queue.peek().toString());
                queue.poll();
                l++;
                if(l>=k){
                    break;
                }
            }
        }

        for(int m:b){
            System.out.println(m);
        }

    }
}
