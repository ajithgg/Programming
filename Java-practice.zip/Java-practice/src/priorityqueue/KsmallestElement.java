package priorityqueue;

import java.util.Collections;
import java.util.PriorityQueue;

public class KsmallestElement {

    public static void main(String[] args) {
        int[] a={5,7,2,3,1,9,8};
        getKlargestElement(a,3);

    }

    private static void getKlargestElement(int[] a,int k){

        PriorityQueue maxQueue=new PriorityQueue(Collections.reverseOrder());

        for(int i=0;i<a.length;i++){
            maxQueue.offer(a[i]);

            if(maxQueue.size()>k){
                maxQueue.poll();
            }

        }
        System.out.println(maxQueue);
       //return maxQueue.
        System.out.println(maxQueue.peek());

    }
}
