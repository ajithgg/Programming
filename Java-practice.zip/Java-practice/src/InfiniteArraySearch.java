public class InfiniteArraySearch {

    public static void main(String[] args) {
        //int start

    }

    static int findRange(int[] arr,int target)
    {
        int start=0;
        int end=1;

        while(target>arr[end])
        {
            int newStart=end+1;
            //end=end+
        }

        return 0;
    }

    private static void binarySearch(int[] arr, int target, int start, int end) {
        //int start=0;
        //int end=arr.length-1;
        int mid = 0;
        int res = 0;

        while (start <= end) {
            mid = (end + start) / 2;
            if (arr[mid] == target) {
                //return arr[mid];
            } else if (target < arr[mid]) {

                end = mid - 1;
            } else {
                //res=arr[mid];
                start = mid + 1;
            }
        }

    }
}
