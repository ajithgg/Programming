public class MaxConsecutiveAnswer {

    public static void main(String[] args) {

        String s = "TFFTFTTT";
        int ans = maxConsecutiveAns(s, 1);
        System.out.println(ans);
    }

    private static int maxConsecutiveAns(String str, int k) {
        int ans = 0;
        int l = 0, r = 0;
        int cnt = 0;
        char[] s = str.toCharArray();

        while (r < s.length) {
            if (s[r] == 'F')
                cnt++;

            while (cnt > k) {
                if (s[l] == 'F')
                    cnt--;

                l++;
            }

            ans = Math.max(ans, r - l + 1);
            r++;
        }

        return ans;
    }
}
