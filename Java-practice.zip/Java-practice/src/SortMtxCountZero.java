public class SortMtxCountZero {

    public static void main(String[] args) {

        int arr[][] = { {0, 0, 0, 0, 1},
                {0, 0, 0, 1, 1},
                {0, 0, 1, 1, 1},
                {0, 1, 1, 1, 1},
                {1, 1, 1, 1, 1}};

        System.out.println("No of Zeros :: "+countZeros(arr));

    }

    private static int countZeros(int[][] mat) {
        int i = 0;
        int j = mat.length - 1;
        int count = 0;
        while (i < mat.length && j >= 0) {
            if (mat[i][j] ==1)
                j--;
            else if (mat[i][j] == 0) {
                count += (j + 1);
                i++;
            }

        }


        return count;
    }
}
