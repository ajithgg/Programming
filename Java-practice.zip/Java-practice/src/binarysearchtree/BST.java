package binarysearchtree;

import java.util.ArrayList;
import java.util.List;

public class BST {

    static class Node {

        Node left, right;
        int data;

        Node(int data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }

    }

    private static boolean searchInBST(Node root, int data) {

        if (root == null)
            return false;

        if (root.data > data) {
            return searchInBST(root.left, data);
        } else if (root.data < data) {
            return searchInBST(root.right, data);
        } else {
            return true;
        }
    }

    public static Node delete(Node root, int val) {

        if (root.data > val) {
            root.left = delete(root.left, val);
        } else if (root.data < val) {
            root.right = delete(root.right, val);
        } else {

            //root.data == val
            //case 1 Deleting leaf nodes
            if (root.left == null && root.right == null)
                return null;

            //case 2 if root's left or right is null
            if (root.left == null)
                return root.right;

            if (root.right == null)
                return root.left;


            Node IS = inOrderSuccessor(root.right);
            root.data = IS.data;
            root.right = delete(root.right, IS.data);
        }
        return root;
    }

    public static void printInRange(Node root, int x, int y) {

        if (root == null)
            return;

        if (root.data >= x && root.data <= y) {
            printInRange(root.left, x, y);
            System.out.print(root.data + " ");
            printInRange(root.right, x, y);
        } else if (root.data >= y) {
            printInRange(root.left, x, y);
        } else {
            printInRange(root.right, x, y);
        }

    }

    private static Node inOrderSuccessor(Node node) {

        while (node.left != null)
            node = node.left;

        return node;
    }

    public static Node insert(Node root, int value) {

        if (root == null) {
            root = new Node(value);
            return root;
        }

        if (root.data > value) {
            root.left = insert(root.left, value);
        } else if (root.data < value) {
            root.right = insert(root.right, value);
        }

        return root;
    }

    public static void inOrder(Node root) {

        if (root == null)
            return;

        inOrder(root.left);
        System.out.print(root.data + " -> ");
        inOrder(root.right);
    }

    public static void printRoot2Leaf(Node root, List<Integer> paths) {

        if (root == null)
            return;

        paths.add(root.data);

        if (root.left == null && root.right == null) {
            System.out.println();
            printLeafPath(paths);
        } else {

            printRoot2Leaf(root.left, paths);
            printRoot2Leaf(root.right, paths);

        }
        //paths.remove(paths.size() - 1);
        paths.clear();

    }

    private static void printLeafPath(List<Integer> paths) {

        paths.forEach(x -> {
            System.out.print(x + " ");
        });
    }


    public static void main(String[] args) {

        int[] val = {8, 5, 3, 1, 4, 6, 10, 11, 14};

        Node root = null;
        for (int i = 0; i < val.length; i++) {
            root = insert(root, val[i]);
        }

        inOrder(root);
        System.out.println(searchInBST(root, 9));
        //delete(root, 5);

        inOrder(root);

        System.out.println();
        printInRange(root, 6, 11);
        System.out.println();

        printRoot2Leaf(root, new ArrayList<>());
    }
}
