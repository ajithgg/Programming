package sorting;

import java.util.Arrays;

public class SelectionSorting {

    public static void main(String[] args) {

        int[] a={4,6,2,9,8,3};

        //Arrays.sort(a);
        int[] sortedArr=selectionSorting(a);
        System.out.println(Arrays.toString(sortedArr));

        String s1=new String("abc");
        String s2=new String("abc");

        String s4 = s1.intern();
        String s5 = s2.intern();

        String k1="abc";
        String k2="abc";


        System.out.println(s1==s2);
        System.out.println(s4==s5);
        System.out.println(k1==k2);

        System.out.println(s1.equals(s2));

    }

    private static int[] selectionSorting(int[] a){

        for(int i=0;i<a.length;i++){

            int minElementIdx=i;

            for(int j=i;j<a.length;j++){

                if(a[minElementIdx]>a[j]){
                    minElementIdx=j;
                }
            }

            int temp=a[i];
            a[i]=a[minElementIdx];
            a[minElementIdx]=temp;

        }

        return a;
    }
}
