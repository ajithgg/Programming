package sorting;

import java.util.Arrays;

public class QuickSort {

    public static void main(String[] args) {

        System.out.println("------------------");
        int[] a = {5, 1, 3, 2, 9, 7};
        int[] aSorted=quickSortFinal(a,0,a.length-1);
        System.out.println(Arrays.toString(aSorted));
    }

    private static int[] quickSortFinal(int[] a, int low, int high) {
        int pt = quickSort(a, low, high);
        if (low < pt - 1) {
            quickSort(a, low, pt - 1);
        } else if (pt < high) {
            quickSort(a, pt, high);
        }

        return a;
    }

    private static int quickSort(int[] a, int low, int high) {

        int pivot = (low + high) / 2;

        while (low <= high) {

            while (a[low] < a[pivot]) {
                low++;
            }
            while (a[high] > a[pivot]) {
                high--;
            }

            if (low <= high) {
                int temp = a[low];
                a[low]=a[high];
                a[high] = temp;
                low++;
                high--;
            }
        }

        return low;
    }
}
