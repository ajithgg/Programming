package Streams;

public class Accountant extends  Employee{

    int accId;

    public static void main(String[] args) {

        Accountant acc=new Accountant();

        System.out.println(acc instanceof Accountant);
        System.out.println(!(acc instanceof Employee));

    }
}
