package Streams;

public class DrawImpl {

    public static void main(String[] args) {

        Drawable draw=new Drawable() {
            @Override
            public void draw() {
                System.out.println("Draw ....");
            }
        };

        draw.draw();
    }
}
