package Streams;

public interface Drawable {

    void draw();
}
