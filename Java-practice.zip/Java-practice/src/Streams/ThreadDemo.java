package Streams;

import java.util.*;

public class ThreadDemo extends Thread{

    @Override
    public void run() {
        System.out.println("Thread ");
    }

    public static void main(String[] args) {

        Map props=new HashMap();
        props.put("key45","some value");
        props.put("key12","some other value");
        props.put("key39","yet another value");

        Set s=props.keySet();
        System.out.println(s);

        //Collections.sort(s);
        //Arrays.sort(s);
        //s=new TreeSet(s);
        System.out.println(s);

        List<Accountant> empList= new ArrayList<>();

        String obj="hello";
        String obj1="world";
        String obj2=obj;
        obj2=" world";
        System.out.println(obj+ " "+obj2);

    }
}
