package Streams;

public class Base {

    final public void show(){
        System.out.println("Base::show() called");
    }
}

class Derived extends Base{


}

class Main{

    public static void main(String[] args) {
        Base b=new Derived();
        b.show();
    }
}
