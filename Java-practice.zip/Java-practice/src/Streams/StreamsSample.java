package Streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class StreamsSample {

    public static void main(String[] args) {

        List<Integer> ls= Arrays.asList(1,2,3,6,5,7);

        List<Integer> modifiedLs=ls.stream().map(x->x*2).collect(Collectors.toList());
        System.out.println(modifiedLs);

        List<Integer> filteredLs=ls.stream().filter(x->x>5).collect(Collectors.toList());
        System.out.println(filteredLs);

        List<Integer> sortedLs=ls.stream().sorted().collect(Collectors.toList());
        System.out.println(sortedLs);

        int minLs=ls.stream().min((x,y)->x-y).get();
        System.out.println(minLs);

        int maxLs=ls.stream().max((x,y)->x-y).get();
        System.out.println(maxLs);

        long count=ls.stream().count();
        System.out.println(count);


        int[] lst= {1,5,4,7,8,9,2};

        IntStream.of(lst).sorted().limit(3).forEach(System.out::print);

        //System.out.println(lst);

    }
}
