package Streams;

public class Employee {

    int id;
}
