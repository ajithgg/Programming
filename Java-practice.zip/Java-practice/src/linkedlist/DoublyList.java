package linkedlist;

public class DoublyList {

    private Node head;

    private class Node {

        int data;
        Node next, prev = null;

        public Node(int data) {
            this.data = data;
        }

        public Node(int data, Node next, Node prev) {
            this.data = data;
            this.next = next;
            this.prev = prev;
        }
    }

    public void insertFirst(int data) {
        Node newNode = new Node(1);
        newNode.next = head;
        newNode.prev = null;

        if (head != null) {
            head.prev = newNode;
        }

        head = newNode;

    }

    public void printDoublyList(){
        Node current=head;
        while(current!=null){
            System.out.print(current.data +" => ");
            current=current.next;
        }
    }

    public static void main(String[] args) {

        DoublyList dst=new DoublyList();
        dst.insertFirst(1);
        dst.printDoublyList();

    }
}
