package linkedlist;

public class LoopSinglyList {

    public static void main(String[] args) {

        createLoopInLinkedList();
        //printList();
        System.out.println(detectLoopInList());

    }

    private static boolean detectLoopInList() {

        ListNode fastPtr = head;
        ListNode slowPtr = head;

        while (fastPtr.next != null && fastPtr.next.next != null) {

            slowPtr = slowPtr.next;
            fastPtr = fastPtr.next.next;

            if (slowPtr == fastPtr)
                return true;
        }

        return false;
    }

    private static ListNode head;

    private static class ListNode {

        int data;
        ListNode next;

        public ListNode(int data) {
            this.data = data;
            this.next = null;
        }
    }

    private static void createLoopInLinkedList() {

        LoopSinglyList sl1 = new LoopSinglyList();
        sl1.head = new ListNode(1);
        ListNode sl2 = new ListNode(2);
        ListNode sl3 = new ListNode(3);
        ListNode sl4 = new ListNode(4);
        ListNode sl5 = new ListNode(5);
        ListNode sl6 = new ListNode(6);

        sl1.head.next = sl2;
        sl2.next = sl3;
        sl3.next = sl4;
        sl4.next = sl5;
        sl5.next = sl6;
        sl6.next = sl4;

    }

    public static void printList() {
        LoopSinglyList.ListNode current = head;
        while (current != null) {
            System.out.print(current.data + " =>");
            current = current.next;
        }
        System.out.print("NULL");
    }
}
