package linkedlist;

public class SinglyList {

    private static ListNode head;

    private static class ListNode {
        private int data; // Can be a generic type
        private ListNode next; // Reference to next ListNode in list

        public ListNode(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public static void main(String[] args) {

        SinglyList sll = new SinglyList();
        sll.head = new ListNode(1);
        ListNode second = new ListNode(2);
        ListNode third = new ListNode(3);
        ListNode fourth = new ListNode(4);
        ListNode fifth = new ListNode(5);

        sll.head.next = second;
        second.next = third;
        third.next = fourth;
        fourth.next = fifth;
        fifth.next = null;

        printList();
        countSize();

        insertNodeAtStart(0);
        printList();
        insertAtLast(6);
        printList();
        insertAtIndex(2);
        System.out.println();
        printList();

        System.out.println("---------");
        removeFirstNode();
        printList();
        System.out.println("*******");
        removeAtGivenIndex(3);
        printList();
    }

    public static void printList() {
        ListNode current = head;
        while (current != null) {
            System.out.print(current.data + " =>");
            current = current.next;
        }
        System.out.print("NULL");
    }

    public static void countSize() {
        ListNode current = head;
        int count = 0;
        while (current != null) {
            count += 1;
            current = current.next;
        }
        System.out.println();
        System.out.println(count);
    }

    public static void insertNodeAtStart(int data) {
        ListNode newNode = new ListNode(data);
        newNode.next = head;
        head = newNode;
    }

    public static void insertAtLast(int a) {

        ListNode node = new ListNode(a);

        ListNode current = head;
        while (current.next != null) {
            current = current.next;
        }

        current.next = node;
        //node.next=null;
    }

    private static void insertAtIndex(int index) {
        ListNode newNode = new ListNode(55);
        if (index == 1) {
            newNode.next = head;
            head = newNode;
        } else {
            ListNode prevNode = head;
            int count = 1;
            while (count < index - 1) {
                prevNode = prevNode.next;
                count++;
            }

            ListNode current = prevNode.next;
            newNode.next = current;
            prevNode.next = newNode;
        }
    }

    private static ListNode removeFirstNode() {
        if (head == null) {
            return null;
        }
        ListNode temp = head;
        head = head.next;
        return head;
    }

    private static void removeAtGivenIndex(int index){
        if(index==1){
            head=head.next;
        }
        else {
            ListNode prev=head;
            int count=1;
            while(count<index-1){
                prev=prev.next;
                count++;
            }
            ListNode current=prev.next;
            prev.next=current.next;
        }
    }
}
