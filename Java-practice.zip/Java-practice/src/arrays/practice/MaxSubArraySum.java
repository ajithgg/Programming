package arrays.practice;

public class MaxSubArraySum {

    public static void main(String[] args) {

        int[] arr = {-2, -3, 4, -1, -2, 1, 5, -3};

        int maxSum=maxSubArrySum(arr);
        System.out.println(maxSum);

    }

    public static int maxSubArrySum(int[] arr) {

        int max_so_far = Integer.MIN_VALUE;
        int max_ending_here = 0;

        for (int a : arr) {
            max_ending_here += a;
            if (max_so_far < max_ending_here)
                max_so_far = max_ending_here;

            if (max_ending_here < 0)
                max_ending_here = 0;

        }
        return max_so_far;
    }
}
