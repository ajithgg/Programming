package arrays.practice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PairSum {

    static class Pair {

        @Override
        public String toString() {
            return "Pair{" +
                    "p1=" + p1 +
                    ", p2=" + p2 +
                    '}';
        }

        int p1;
        int p2;

        Pair(int p1, int p2) {
            this.p1 = p1;
            this.p2 = p2;
        }

    }

    public static void main(String[] args) {

        int[] arr={1,2,3,4,5,6,7,8,9};
        int sum=12;
        printPairSum(arr,sum);
    }

    public static void printPairSum(int[] arr, int sum) {

        Map<Integer, Integer> map = new HashMap<>();
        List<Pair> pairsList = new ArrayList<>();
        for (int i : arr) {

            int temp = sum - i;
            if (map.containsKey(temp)) {

                pairsList.add(new Pair(i, temp));
            }

            map.put(i,temp);
        }


        System.out.println(pairsList);
    }
}
