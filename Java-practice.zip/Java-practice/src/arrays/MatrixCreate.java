package arrays;

import java.util.Scanner;

public class MatrixCreate {

    public static void main(String[] args) {

        Scanner scn=new Scanner(System.in);

        int rows=scn.nextInt();
        int columns=scn.nextInt();
        System.out.println("Rows == "+rows+" columns == "+columns);

        int[][] nums=new int[rows][columns];

        for(int i=0;i< nums.length;i++)
        {
            for(int j=0;j< nums.length;j++)
            {
                nums[i][j]=scn.nextInt();
            }
        }

        System.out.println("***************************");

        for(int m=0;m<nums.length;m++)
        {
            for(int n=0;n< nums.length;n++)
                System.out.print(nums[m][n]+ " ");

            System.out.println();
        }


    }
}
