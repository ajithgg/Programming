package arrays;

import java.util.Arrays;

public class MinimumPlatforms {

    public static void main(String[] args) {

        int[] arrival = new int[]{900, 940, 950, 1100, 1500, 1800};
        int[] departure = new int[]{910, 1200, 1120, 1130, 1900, 2000};

        int platform = findPlatform(arrival, departure, departure.length);
        System.out.println(platform);

    }

    static int findPlatform(int arr[], int dep[], int n) {
        Arrays.sort(arr);
        Arrays.sort(dep);
        int platform = 1;

        int arrIndex = 1;
        int depIndex = 0;

        while (arrIndex < n) {
            if (arr[arrIndex] <= dep[depIndex]) {
                platform++;
            } else {
                depIndex++;
            }

            arrIndex++;
        }


        return platform;
    }
}
