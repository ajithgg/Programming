package arrays;

public class LongestSubString {


    public static void main(String[] args) {


        int maxUnique=lengthOfLongestSubstring("pwwkew");
        System.out.println(maxUnique);
    }

    public static int lengthOfLongestSubstring(String s) {
        int maxUniqueSize=0;
        char[] stArry=s.toCharArray();

        StringBuffer sb=new StringBuffer();
        for(char c:stArry)
        {
            if (sb.toString().contains(String.valueOf(c))) {
                while(sb.toString().contains(String.valueOf(c))){
                    String str=sb.toString();
                    str =sb.substring(1,sb.length());
                    sb=new StringBuffer(str);
                }
                sb.append(c);
                //maxUniqueSize=sb.length();

            } else {
                sb.append(c);
                maxUniqueSize=Math.max(maxUniqueSize,sb.length());
            }
        }

        return maxUniqueSize;
    }
}
