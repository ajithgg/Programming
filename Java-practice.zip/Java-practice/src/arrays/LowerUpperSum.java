package arrays;

public class LowerUpperSum {

    public static void main(String[] args) {

        int[][] arr={{6, 5, 4},
                {1, 2, 5},
                {7, 9, 7}};

        System.out.println(arr.length);
        int lowSum=0;
        for(int i=0;i<arr.length;i++)
        {
            for(int j=0;j<=i;j++)
            {
                lowSum+= arr[i][j];
            }
        }

        int upperSum=0;
        for(int i=0;i<arr.length;i++)
        {
            for(int j=arr.length-1;j>=i;j--)
                upperSum+=arr[i][j];

        }

        System.out.println("lowSum === "+lowSum+" upperSum ==== "+upperSum);
    }
}
