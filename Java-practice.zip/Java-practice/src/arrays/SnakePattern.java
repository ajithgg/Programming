package arrays;

public class SnakePattern {

    public static void main(String[] args) {

        int[][] arr={{6, 5, 4},
                {1, 2, 5},
                {7, 9, 7}};

        for(int i=0;i<arr.length;i++)
        {
            int k=0;
            if(i%2==0)
            {
                for(k=0;k<arr.length;k++)
                    System.out.print(arr[i][k]+" ");
            }else
            {
                for(k=arr.length-1;k>=0;k--)
                    System.out.print(arr[i][k]+" ");
            }


        }
    }
}
