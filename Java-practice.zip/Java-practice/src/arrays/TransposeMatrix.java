package arrays;

public class TransposeMatrix {

    public static void main(String[] args) {

        int[][] arr={{6, 5, 4},
                {1, 2, 5},
                {7, 9, 7}};

        printMatrix(arr);

        for(int i=0;i< arr.length;i++)
        {
            for(int j=0;j<i;j++)
            {
                int temp=0;
                temp=arr[i][j];
                arr[i][j]=arr[j][i];
                arr[j][i]=temp;
            }

        }

        System.out.println("----------------------");
        printMatrix(arr);
    }

    private static void printMatrix(int[][] nums) {
        for(int m=0;m<nums.length;m++)
        {
            for(int n=0;n< nums.length;n++)
                System.out.print(nums[m][n]+ " ");

            System.out.println();
        }
    }
}
