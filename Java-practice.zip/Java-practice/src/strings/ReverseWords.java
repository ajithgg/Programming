package strings;

public class ReverseWords {

    public static void main(String[] args) {

        reverseStrWords("this is an amazing program");
    }

    private static void reverseStrWords(String s) {

        String[] str = s.split(" ");
        StringBuilder sb = new StringBuilder();
        for (int i = str.length - 1; i >= 0; i--) {
            sb.append(str[i]+" ");
        }
        System.out.println(sb.toString());
    }
}
