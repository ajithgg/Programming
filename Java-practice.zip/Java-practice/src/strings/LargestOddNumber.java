package strings;

public class LargestOddNumber {

    public static void main(String[] args) {

        largestOddNumber("5278");
        System.out.println(largestOddNumber2("35427"));

    }

    private static String largestOddNumber2(String num) {

        for (int i = num.length()-1; i >=0 ; i--) {
            char c=num.charAt(i);

            if(c%2==1){
                return num.substring(0,i+1);
            }
        }
        return "";
    }

    private static void largestOddNumber(String num) {

        String[] s = num.split("");

        int largestOdd = Integer.MIN_VALUE;
        for (int i = 0; i < s.length; i++) {

            if (Integer.valueOf(s[i]) % 2 != 0)
                largestOdd = Math.max(largestOdd, Integer.valueOf(s[i]));
        }

        System.out.println("Largest odd no :: "+largestOdd);
    }
}
