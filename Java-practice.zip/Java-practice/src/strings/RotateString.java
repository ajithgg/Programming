package strings;

import java.util.Arrays;
import java.util.stream.Collectors;

public class RotateString {

    public static void main(String[] args) {

        System.out.println(rotateString("abcde","qwert"));

    }

    public static boolean rotateString(String s, String goal) {

        if(s.length()!=goal.length())
            return false;

        String rot = rotatedString(s);

        if (goal.equalsIgnoreCase(rot)) {
            return true;
        }else{
            return rotateString(rot,goal);
        }

    }

    private static String rotatedString(String s) {
        String[] str = s.split("");
        String a = str[0];

        for (int i = 0; i < str.length-1; i++) {
            str[i] = str[i + 1];

        }
        str[str.length - 1] = a;

        return Arrays.stream(str).collect(Collectors.joining());
    }
}
