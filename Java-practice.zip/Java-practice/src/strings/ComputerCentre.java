package strings;

import java.util.HashMap;
import java.util.Map;

public class ComputerCentre {

    public static void main(String[] args) {

        String s="ABCCBA";
        int count=getUnavailableCount(s,2);
        System.out.println("Unavailable seats :: "+count);

    }

    public static int getUnavailableCount(String s, int n) {

        int count = 0;
        String[] str = s.split("");

        Map<String, Integer> map = new HashMap<>();

        for (int i = 0; i < str.length; i++) {

            if (map.containsKey(str[i])) {
                map.put(str[i], map.get(str[i]) + 1);
                if (map.get(str[i]) == 2) {
                    map.remove(str[i]);
                    n++;
                }

            } else if(n>0){
                map.put(str[i], 1);
                n--;
            }else{
                count++;
            }



        }
        return count;
    }
}
