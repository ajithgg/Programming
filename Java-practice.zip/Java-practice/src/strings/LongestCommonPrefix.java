package strings;

public class LongestCommonPrefix {

    public static void main(String[] args) {

        String arr[] = {"geeksforgeeks", "geeks",
                "geek", "geezer"};
        int n = arr.length;

        String s=longestCommonPrefix(arr);
        System.out.println(s);

    }

    private static String longestCommonPrefix(String[] str){

        String shortStr=shortestString(str);
        char current;
        String result = ""; // Our resultant string
        for (int i = 0; i < shortStr.length(); i++) {

            current = str[0].charAt(i);

            for (int j = 1; j < str.length; j++)
            {
                if (str[j].charAt(i) != current)
                {
                    return result;
                }
            }

            // Append to result
            result += (current);
        }



        return result;
    }

    private static String shortestString(String[] s){
        int i=s[0].length();
        String str=s[0];
        for (String a : s) {
            if (a.length() < i) {
                i = a.length();
                str=a;
            }
        }
        return str;
    }
}
