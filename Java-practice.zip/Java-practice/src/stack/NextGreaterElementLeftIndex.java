package stack;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class NextGreaterElementLeftIndex {

    class Pair {

        int first;
        int second;

        Pair(int first, int second) {
            this.first = first;
            this.second = second;
        }
    }

    public static void main(String[] args) {

        int[] a = {100,80,60,70,60,75,85};
        NextGreaterElementLeftIndex nglIdx=new NextGreaterElementLeftIndex();
        List<Integer> ls = nglIdx.nextGreaterElementLeftIdx(a);

        System.out.println(ls);
    }

    private List<Integer> nextGreaterElementLeftIdx(int[] a) {

        List<Integer> ls = new ArrayList<>();
        Stack<Pair> s = new Stack<>();
        for (int i = 0; i < a.length; i++) {

            if (s.isEmpty())
                ls.add(-1);
            else if (s.size() > 0 && s.peek().first > a[i]) {
                ls.add(s.peek().second);
            } else if (s.size() > 0 && s.peek().first <= a[i]) {

                while (s.size() > 0 && s.peek().first <= a[i]) {
                    s.pop();
                }

                if (s.isEmpty())
                    ls.add(-1);
                else
                    ls.add(s.peek().second);
            }

            s.push(new Pair(a[i],i));
        }

        return ls;
    }
}
