package stack;

import java.util.Stack;

public class MinimumAddToMakeBalanced {

    public static void main(String[] args) {
        String brackets="())";
        int checkBrackets=minAddToMakeBalanced(brackets);
        System.out.println(checkBrackets);

    }

    public static int minAddToMakeBalanced(String s) {

        // ())

        Stack<Character> stack = new Stack<>();

        for (char c : s.toCharArray()) {

            //stack.push(c);

            if (c == ')') {
                if (!stack.isEmpty() && stack.peek() == '(') {
                    stack.pop();
                }else {
                    stack.push(c);
                }
            } else {
                stack.push(c);
            }

        }

        return stack.size();
    }
}
