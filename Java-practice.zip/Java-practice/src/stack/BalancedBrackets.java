package stack;

import java.util.Stack;

public class BalancedBrackets {

    public static void main(String[] args) {

        String s = "[({))]";
        System.out.println(checkBalancedBracket(s));

    }

    private static boolean checkBalancedBracket(String s) {

        char[] str = s.toCharArray();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < str.length; i++) {

            if (str[i] == '(' || str[i] == '[' || str[i] == '{') {
                stack.push(str[i]);
            } else {

                if (stack.isEmpty())
                    return false;
                else if (!isMatching(stack.peek(), str[i]))
                    return false;
                else
                    stack.pop();

            }
        }
        return stack.isEmpty();
    }

    public static boolean checkBalancedBrackets(String s){

        Stack<Character> st=new Stack<>();

        char[] c=s.toCharArray();

        for (int i = 0; i < c.length; i++) {

            if(c[i]=='[' || c[i]=='{' || c[i]=='(')
            {
                st.push(c[i]);
            }else{

                if(st.isEmpty())
                    return false;
                else if(!isMatching(st.peek(),c[i])){
                    return false;
                }else{
                    st.pop();
                }

            }

        }

        return st.isEmpty();
    }

    private static boolean isMatching(char a, char b) {

        return ((a == '(' && b == ')') || (a == '[' && b == ']') || (a == '{' && b == '}'));
    }
}
