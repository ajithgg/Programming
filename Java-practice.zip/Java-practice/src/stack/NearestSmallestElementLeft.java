package stack;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class NearestSmallestElementLeft {

    public static void main(String[] args) {

        int[] a={4,5,2,10,8};
        List<Integer> ls=nearestSmallestElementLeft(a);
        System.out.println(ls);

    }

    private static List<Integer> nearestSmallestElementLeft(int[] a){

        Stack<Integer> s=new Stack<>();
        List<Integer> ls=new ArrayList<>();

        for(int i=0;i<a.length;i++){

            if(s.isEmpty())
                ls.add(-1);
            else if(s.size()>0 && s.peek()<a[i])
                ls.add(s.peek());
            else if(s.size()>0 && s.peek()>=a[i]){

                while(s.size()>0 && s.peek()>=a[i])
                    s.pop();

                if(s.isEmpty())
                    ls.add(-1);
                else
                    ls.add(s.peek());

            }

            s.push(a[i]);
        }

        return ls;
    }
}
