package stack;

public class MaxAreaHistogram {
}
