package stack;

import java.util.*;

public class NextGreaterElement {

    public static void main(String[] args) {

        int[] a={1,3,2,4};
        List<Integer> ls=getGreaterElements(a);

        System.out.println(ls);

    }

    private static List<Integer> getGreaterElements(int[] a) {
        Vector<Integer> ls = new Vector<>();
        Stack<Integer> s = new Stack<>();

        for (int i = a.length - 1; i >= 0; i--) {
            if (s.size() == 0) {
                ls.add(-1);
            } else if (s.size() > 0 && s.peek() > a[i]) {
                ls.add(s.peek());
            } else if (s.size() > 0 && s.peek() <= a[i]) {

                while (s.size() > 0 && s.peek() <= a[i]) {
                    s.pop();
                }

                if (s.size() == 0) {
                    ls.add(-1);
                } else {
                    ls.add(s.peek());
                }
            }
            s.push(a[i]);
        }


        return ls;
    }
}
