package stack;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class NextGreaterElementLeft {

    public static void main(String[] args) {

        int[] a={1,3,2,4};
        List<Integer> ls=nextGreaterElementLeft(a);

        System.out.println(ls);
    }

    private static List<Integer> nextGreaterElementLeft(int[] a){

        List<Integer> ls=new ArrayList<>();
        Stack<Integer> s=new Stack<>();
        for(int i=0;i<a.length;i++){

            if(s.isEmpty())
                ls.add(-1);
            else if(s.size()>0 && s.peek()>a[i]){
                ls.add(s.peek());
            }else if(s.size()>0 && s.peek()<=a[i]){

                while(s.size()>0 && s.peek()<=a[i]){
                    s.pop();
                }

                if(s.isEmpty())
                    ls.add(-1);
                else
                    ls.add(s.peek());
            }

            s.push(a[i]);
        }

        return ls;
    }
}
