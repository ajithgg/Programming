public class MaxSubArraySum {

    public static void main(String[] args) {

        int[] a={-2, -5, 6, -2, -3, 1, 5, -6};

        int maxSum=maxSubArraySum(a);
        System.out.println(maxSum);

    }

    private static int maxSubArraySum(int[] a) {
        int sum = 0;
        int maxSum = Integer.MIN_VALUE;
        int startIndex=0;
        int endIndex=0;
        for (int i = 0; i < a.length; i++) {
            sum += a[i];
            maxSum = Math.max(sum, maxSum);
            if (sum < 0)
                sum = 0;

        }
        return maxSum;
    }
}
