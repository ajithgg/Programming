package arrays3;

public class BuySellStock {

    public static void main(String[] args) {
        int[] a={5,1,6,9,2,3};

        int maxPro=maxProfit(a);
        System.out.println(maxPro);

        int mxProfit=maxProfitOptimized(a);
        System.out.println(mxProfit);

    }

    private static int maxProfitOptimized(int[] arry) {

        int min = Integer.MAX_VALUE;
        int maxPro = 0;
        for (int i = 0; i < arry.length; i++) {

            min = Math.min(arry[i], min);
            maxPro = Math.max(maxPro, arry[i] - min);
        }
        return maxPro;
    }

    private static int maxProfit(int[] arry){

        int maxPro=0;

        for(int i=0;i<arry.length;i++){

            for(int j=i;j<arry.length;j++){
                if(arry[j]>arry[i]){
                    maxPro=Math.max(arry[j]-arry[i],maxPro);
                }
            }

        }

      return maxPro;
    }
}
