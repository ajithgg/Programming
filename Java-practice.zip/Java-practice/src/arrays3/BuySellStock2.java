package arrays3;

public class BuySellStock2 {


    public static void main(String[] args) {

        int[] a={5,2,6,1,4,7,3,6};


        int maxProfit=maxProfit(a);
        System.out.println(maxProfit);
    }

    static int maxProfit(int[] a){


        int profit=0;
        for (int i = 0; i < a.length-1; i++) {

            if(a[i+1]>a[i]){
                profit+=a[i+1]-a[i];
            }
        }

        return profit;
    }
}
