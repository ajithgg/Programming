package arrays3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LeadersInArray {

    public static void main(String[] args) {
        List<Integer> ls= Arrays.asList(15,18,5,3,6,2);
        List<Integer> maxLs=leadersInArray(ls);
        System.out.println(maxLs);

    }

    private static List<Integer> leadersInArray(List<Integer> leadersList){
        List<Integer> leadersfoundLs=new ArrayList<>();
        int maxValue=leadersList.get(leadersList.size()-1);
        leadersfoundLs.add(maxValue);
        for(int i=leadersList.size()-1;i>=0;i--){

            if(leadersList.get(i)>maxValue){
                leadersfoundLs.add(leadersList.get(i));
                maxValue=leadersList.get(i);
            }


        }

        return leadersfoundLs;
    }
}
