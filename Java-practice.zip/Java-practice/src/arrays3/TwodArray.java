package arrays3;

public class TwodArray {

    public static void main(String[] args) {
        int[][] lands={{1,1,0},{1,1,0},{0,0,1}};
        countLands(lands);
    }

    private static int countLands(int[][] lands){
        int land=0;

        for(int i=0;i<lands.length;i++){
            for(int j=0;j<lands.length;j++){
                System.out.print(lands[i][j]+" ");
            }
            System.out.println();
        }

     return 0;
    }
}
