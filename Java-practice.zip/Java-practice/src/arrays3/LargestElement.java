package arrays3;

public class LargestElement {

    public static void main(String[] args) {
        int[] a={10,2,60,20,98};
        int maxElement=findLargestElement(a);
        System.out.println(maxElement);

    }

    private static int findLargestElement(int[] a){

        int maxElement=Integer.MIN_VALUE;

        for (int e :a) {
            maxElement=Math.max(maxElement,e);
        }

        return maxElement;
    }
}
