package arrays3;

import java.util.Arrays;

public class MoveZerosEnd {

    public static void main(String[] args) {

        int a[] = {1, 0, 8, 5, 2, 0, 3, 7};
        int[] arr=moveZeros(a);
        System.out.println(Arrays.toString(arr));
    }

    private static int[] moveZeros(int[] a) {
        int j = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i] != 0 && a[j] == 0) {
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }

            if (a[j] != 0) {
                j++;
            }
        }
        return a;
    }
}
