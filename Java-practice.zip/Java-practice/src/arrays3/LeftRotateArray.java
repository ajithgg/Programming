package arrays3;

import java.util.Arrays;

public class LeftRotateArray {

    public static void main(String[] args) {

        int[] a={1,2,3,4,5};
        int[] maray=leftRotate(a,2);
        System.out.println(Arrays.toString(maray));

    }

    private static int[] leftRotate(int[] a,int k){

        int element=0;
        int count=Integer.MIN_VALUE;
        //int k=1;
        for(int i=0;i<k;i++){

            element=a[i];

            for(int j=i+1;j<a.length;j++){
                a[j-1]=a[j];
            }

            a[a.length-1]=element;
        }

        return a;
    }
}
