package arrays3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PairSum {

    public static void main(String[] args) {

        int[] a={1,0,-5,4,2,2,3,-2};
        findTwoSum(a,1);

    }

    public static void findTwoSum(int[] arr, int target) {

        Arrays.sort(arr);
        List<List<Integer>> pairList=new ArrayList<>();

        int start = 0;
        int end = arr.length - 1;

        while (start<end){

            int t=target-arr[start];

            if(t==target){
                pairList.add(Arrays.asList(arr[start],arr[end]));
                start++;
                end--;
            }else if(t<target){
                start++;
            }else{
                end--;
            }
        }


        System.out.println(pairList);
    }
}
