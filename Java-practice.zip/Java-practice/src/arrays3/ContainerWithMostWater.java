package arrays3;

public class ContainerWithMostWater {

    public static void main(String[] args) {

        int[] a = {1, 8, 6, 2, 5, 4, 8, 3, 7};

        int maxArea=maxAreaContainer(a);
        System.out.println("Max area :: "+maxArea);

    }

    private static int maxAreaContainer(int[] height) {

        int l = 0;
        int r = height.length - 1;
        int max = 0;

        while (l < r) {

            int min_h = Math.min(height[l], height[r]);
            int len = r - l;
            int currentArea = min_h * len;
            max = Math.max(currentArea, max);

            if (height[l] < height[r])
                l++;
            else
                r--;
        }

        return max;
    }
}
