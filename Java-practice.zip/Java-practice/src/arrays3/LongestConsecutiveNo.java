package arrays3;

public class LongestConsecutiveNo {

    public static void main(String[] args) {
        int[] a={2,5,6,7,8,3,1};
        int count=longestConsecutiveNo(a);
        System.out.println(count);
    }

    private static int longestConsecutiveNo(int[] a) {

        if (a == null || a.length <= 0)
            return 0;

        int prev = a[0];
        int count = 1;
        int ans = 1;
        for (int i = 1; i < a.length; i++) {

            if (a[i] == prev + 1) {
                count++;
            } else
                count = 1;

            prev = a[i];
            ans = Math.max(ans, count);

        }
        return ans;
    }
}
