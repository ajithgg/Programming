package arrays3;

import java.util.Arrays;

public class MinimumPlatform {

    public static void main(String[] args) {

        int[] arrival = new int[]{900, 940, 950, 1100, 1500, 1800};
        int[] departure = new int[]{910, 1200, 1120, 1130, 1900, 2000};
        int minPlatform=findMinimumPlatforms(arrival,departure);
        System.out.println(minPlatform);

    }

    public static int findMinimumPlatforms(int[] arrival,int[] dep){

        Arrays.sort(arrival);
        Arrays.sort(dep);

        int i=1,j=0,minPlatform=1,res=1;

        while(i< arrival.length){

            if(arrival[i]<=dep[j]){
                minPlatform++;
                i++;
            }else
            {
                //minPlatform--;
                j++;
            }



        }


        return res;
    }
}
