package arrays3;

public class MatrixSetZero {

    public static void main(String[] args) {

        int[][] matrix = {{0, 1, 1}, {1, 0, 1}, {1, 1, 1}};
        setMatZeros(matrix);
        //setMatrixZeros2(matrix);

    }

    public static void setMatZeros(int[][] matrix) {

        int rows = matrix.length, cols = matrix[0].length;

        for (int i = 0; i < rows; i++) {

            for (int j = 0; j < cols; j++) {

                //check if mat element is zero
                if (matrix[i][j] == 0) {

                    int ind = i - 1;

                    while (ind >= 0) {
                        if (matrix[ind][j] != 0)
                            matrix[ind][j] = -1;
                        ind--;
                    }

                    ind = i + 1;

                    while (ind < rows) {
                        if (matrix[ind][j] != 0) {
                            matrix[ind][j] = -1;
                        }
                        ind++;
                    }

                    ind = j - 1;
                    while (ind >=0) {
                        if (matrix[i][ind] != 0) {
                            matrix[i][ind] = -1;

                        }
                        ind--;
                    }
                    ind = j + 1;
                    while (ind < cols) {
                        if (matrix[i][ind] != 0) {
                            matrix[i][ind] = -1;

                        }
                        ind++;
                    }

                }
            }
        }

        printMatrix(matrix);

        for(int i=0;i<rows;i++){
            for(int j=0;j<cols;j++){

                if(matrix[i][j]<=0)
                    matrix[i][j]=0;
            }
        }

        printMatrix(matrix);
    }

    public static void setMatrixZeros2(int[][] matrix){

        int rows=matrix.length,cols=matrix[0].length;

        for(int i=0;i<rows;i++){

            for(int j=0;j<cols;j++){

                if(matrix[i][j]==0){

                    int ind=i-1;
                    while(ind>=0){
                        if(matrix[ind][j]!=0){
                            matrix[ind][j]=-1;
                        }
                        ind--;
                    }

                    ind=i+1;
                    while(ind<rows){
                        if (matrix[ind][j] != 0)
                            matrix[ind][j] = -1;

                        ind++;
                    }

                    ind=j-1;
                    while(ind>=0){
                        if(matrix[i][ind]!=0)
                            matrix[i][ind]=-1;

                        ind--;
                    }

                    ind=j+1;
                    while(ind<cols){
                        if(matrix[i][ind]!=0)
                            matrix[i][ind]=-1;

                        ind++;
                    }
                }
            }

        }


        printMatrix(matrix);
    }

    public static void printMatrix(int[][] mat) {

        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat.length; j++) {
                System.out.print(" "+mat[i][j]+" ");
            }
            System.out.println();
        }
    }
}
