package dynamicprogramming;

public class KnapSackTabulation {

    public static void main(String[] args) {

        int[] wt = {1, 3, 4, 5};
        int[] val = {1, 4, 5, 7};
        int w = 7;
        int n = wt.length;
        int res = knapsackTab(wt, val, w, n);
        System.out.println(res);

    }

    public static int knapsackTab(int[] wt, int[] val, int w, int n) {

        int[][] dp = new int[n + 1][w + 1];

        int res = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < w; j++) {

                if (i == 0 || j == 0)
                    dp[i][j] = 0;
                else if (wt[i - 1] > j) {
                    dp[i][j] = dp[i - 1][j];
                } else {

                    dp[i][j] = Math.max(dp[i - 1][j], val[i - 1] + dp[i - 1][w - wt[i - 1]]);
                }

                res = dp[i][j];
            }
        }


        return res;
    }
}
