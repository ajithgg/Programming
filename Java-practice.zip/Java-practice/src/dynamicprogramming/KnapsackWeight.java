package dynamicprogramming;

public class KnapsackWeight {

    public static void main(String[] args) {

        int[] wt = {1, 3, 4, 5};
        int[] val = {1, 4, 5, 7};
        int w = 7;
        int n=wt.length;

        // Declare the table dynamically
        int dp[][] = new int[n + 1][w + 1];

        for (int i = 0; i < n + 1; i++)
            for (int j = 0; j < w + 1; j++)
                dp[i][j] = -1;

        int maxVal = kanpsackRecusrsive(wt, val, w, wt.length,dp);

        System.out.println(maxVal);
    }

    public static int kanpsackRecusrsive(int[] wt, int[] val, int w, int n,int[][] dp) {

        if (n == 0 || w == 0)
            return 0;

        if(dp[n][w]!=-1)
            return dp[n][w];

        if (wt[n - 1] <= w)
            return dp[n][w]=Math.max(val[n - 1] + kanpsackRecusrsive(wt, val, w - wt[n - 1], n - 1,dp),
                    kanpsackRecusrsive(wt, val, w, n - 1,dp));
        else if (wt[n - 1] > w)
            return dp[n][w]=kanpsackRecusrsive(wt, val, w, n - 1,dp);

        return 0;
    }
}
