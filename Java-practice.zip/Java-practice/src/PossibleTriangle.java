import java.util.Arrays;

public class PossibleTriangle {

    public static void main(String[] args) {

        int[] a={4, 6, 3, 7};
        int n=possibleTriangles(a);
        System.out.println(n);

    }

    private static int possibleTriangles(int[] a) {
        Arrays.sort(a);
        int count = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {
                for (int k = j + 1; k < a.length; k++) {
                    if (a[i] + a[j] > a[k])
                        count += 1;
                }
            }
        }
        return count;
    }
}
