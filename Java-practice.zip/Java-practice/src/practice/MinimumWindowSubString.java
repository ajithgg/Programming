package practice;

import java.util.HashMap;
import java.util.Map;

public class MinimumWindowSubString {

    public static void main(String[] args) {

        String s = "this is a test string";
        String pattern = "tist";

        System.out.println(minimumWindowString(s, pattern));

    }

    public static String minimumWindowString(String s, String pattern) {

        int i = 0, j = 0;
        int min = Integer.MAX_VALUE;

        int start = 0;
        int end = 0;

        char[] pattArray = pattern.toCharArray();
        Map<Character, Integer> patternMap = new HashMap<>();
        for (char c : pattArray) {
            patternMap.put(c, patternMap.getOrDefault(c, 0) + 1);
        }

        int count = patternMap.size();

        while (j < s.length()) {

            if (patternMap.containsKey(s.charAt(j))) {

                patternMap.put(s.charAt(j), patternMap.get(s.charAt(j)) - 1);

                if (patternMap.get(s.charAt(j)) == 0)
                    count--;
            }

            if (count > 0) {

            } else {

                while (count == 0) {

                    if (min > j - i + 1) {
                        min = j - i + 1;
                        start = i;
                        end = j + 1;
                    }

                    if (patternMap.containsKey(s.charAt(i))) {

                        patternMap.put(s.charAt(i), patternMap.get(s.charAt(i)) + 1);
                        if (patternMap.get(s.charAt(i)) == 1)
                            count++;
                    }

                    i++;
                }
            }

            j++;
        }


        return s.substring(start,end);
    }


}
