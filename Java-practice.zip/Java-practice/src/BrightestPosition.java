public class BrightestPosition {

    public static void main(String[] args) {


    }


}
