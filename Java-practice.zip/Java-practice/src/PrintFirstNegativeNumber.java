public class PrintFirstNegativeNumber {

    public static void main(String[] args) {

        int[] a={-8, 2, 3, -6, 10};
        printFirstNegativeNum(a,a.length,2);

    }

    static void printFirstNegativeNum(int[] arr, int n, int k) {
        boolean flag = false;
        for (int i = 0; i < n; i++) {
            flag = false;

            for (int j = i; j < i + k; j++) {
                if (arr[j] < 0) {
                    System.out.print(arr[j]+" ");
                    flag=true;
                    break;
                }

            }

            if(!flag)
                System.out.print(0+" ");

        }
    }

}
