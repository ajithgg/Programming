public class FloorElement {

    public static void main(String[] args) {

        int[] a={1,2,3,4,8,10,12,19};
        int res=findFloorElement(a,5);
        System.out.println(res);
    }

    private static int findFloorElement(int[] arr,int target)
    {
        int start=0;
        int end=arr.length-1;
        int mid=0;
        int res=0;

        while(start<=end)
        {
            mid=(end+start)/2;
            if(arr[mid]==target)
            {
                return arr[mid];
            }else if(target<arr[mid])
            {

                end=mid-1;
            }else{
                res=arr[mid];
                start=mid+1;

            }

        }

        return res;
    }
}
