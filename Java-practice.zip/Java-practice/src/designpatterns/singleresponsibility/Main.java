package designpatterns.singleresponsibility;

import java.math.BigDecimal;

public class Main {

    public static void main(String[] args) {


        Account account = new Account();
        account.setFirstname("Ajith");
        account.setTotalAmount(new BigDecimal(2000));
        account.setAccountNumber(12345);
        AccountOperations accountOps = new AccountOperations();
        accountOps.addAccount(account);

        Account beforeUpdate = accountOps.getAccount(12345);
        System.out.println(beforeUpdate);
        TransactionOperations transactionOps = new TransactionOperations();
        transactionOps.deposit(new BigDecimal(500), 12345);

        Account updatedAccount = accountOps.getAccount(12345);
        System.out.println(updatedAccount);

    }
}
