package designpatterns.singleresponsibility;

import java.math.BigDecimal;

public class TransactionOperations {

    public void deposit(BigDecimal amount, int accountNumber) {

        AccountOperations accountOps = new AccountOperations();
        Account account = accountOps.getAccount(accountNumber);
        account.setTotalAmount(account.getTotalAmount().add(amount));
    }

    public void withDraw(BigDecimal amount, int accountNumber) {

        AccountOperations accountOps = new AccountOperations();
        Account account = accountOps.getAccount(accountNumber);
        account.setTotalAmount(account.getTotalAmount().subtract(amount));

    }
}
