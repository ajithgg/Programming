package designpatterns.liskov.bad;

public interface LoanPayment {

    public void doPayment(int amount);
    public void forecloseLone();
    public void doRepayment(int amount);
}
