package designpatterns.liskov.bad;

public class HomeLoan implements LoanPayment{

    @Override
    public void doPayment(int amount) {

    }

    @Override
    public void forecloseLone() {

    }

    @Override
    public void doRepayment(int amount) {

    }
}
