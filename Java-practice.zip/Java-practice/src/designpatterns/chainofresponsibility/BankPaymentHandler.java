package designpatterns.chainofresponsibility;

public class BankPaymentHandler extends PaymentHandler {


    @Override
    public void handlePayment(double amt) {

        if (amt <= 500) {
            System.out.println("Paid using bank account: $ " + amt);
        } else {
            next.handlePayment(amt);
        }
    }
}
