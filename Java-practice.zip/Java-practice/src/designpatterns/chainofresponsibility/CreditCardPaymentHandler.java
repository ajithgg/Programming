package designpatterns.chainofresponsibility;

public class CreditCardPaymentHandler extends PaymentHandler {

    @Override
    public void handlePayment(double amt) {
        if (amt <= 1000) {
            System.out.println("Paid using Credit Card : $ " + amt);
        } else {
            next.handlePayment(amt);
        }
    }
}
