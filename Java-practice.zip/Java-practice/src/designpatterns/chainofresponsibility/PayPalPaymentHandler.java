package designpatterns.chainofresponsibility;

public class PayPalPaymentHandler extends PaymentHandler {

    @Override
    public void handlePayment(double amt) {

        if (amt <= 1500) {
            System.out.println("Handling payment through paypal : $ " + amt);
        } else {
            next.handlePayment(amt);
        }
    }
}
