package designpatterns.composite;

public interface Department {

    void printDepartmentName();
}
