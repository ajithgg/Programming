package designpatterns.factory;

public class MacSystem extends  OperatingSystem{

    public MacSystem(String architecture, String version){
        super(architecture, version);
    }

    @Override
    public void changeDir() {
        System.out.println("Mac System changeDir");
    }

    @Override
    public void removeDir() {
        System.out.println("Mac System removeDir");
    }
}
