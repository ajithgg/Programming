package designpatterns.factory;

public class OsFactory {

    private OsFactory() {

    }

    public static OperatingSystem getInstance(String type, String version, String architecture) {
        switch (type) {
            case "WINDOWS":
                return new WindowsSystem(architecture, version);
            case "MAC":
                return new MacSystem(architecture, version);
            default:
                throw new IllegalArgumentException("Type not supported");
        }
    }


}
