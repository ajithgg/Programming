package designpatterns.factory;

public abstract class OperatingSystem {

    private String architecture;

    public OperatingSystem(String architecture, String version) {
        this.architecture = architecture;
        this.version = version;
    }

    private String version;

    public String getArchitecture() {
        return architecture;
    }

    public void setArchitecture(String architecture) {
        this.architecture = architecture;
    }

    public abstract void changeDir();
    public abstract void removeDir();
}
