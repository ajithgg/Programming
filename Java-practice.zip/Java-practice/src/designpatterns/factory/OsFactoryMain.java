package designpatterns.factory;

public class OsFactoryMain {

    public static void main(String[] args) {

        OperatingSystem osSystem = OsFactory.getInstance("WINDOWS", "1.0", "windows kernel");

        osSystem.changeDir();
    }
}
