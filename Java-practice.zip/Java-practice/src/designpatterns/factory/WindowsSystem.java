package designpatterns.factory;

public class WindowsSystem extends OperatingSystem{

    public WindowsSystem(String architecture, String version) {
        super(architecture, version);
    }

    @Override
    public void changeDir() {
        System.out.println("Windows System changeDir");
    }

    @Override
    public void removeDir() {
        System.out.println("Windows System removeDir");
    }
}
