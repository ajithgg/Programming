package designpatterns.decorator;

public interface Pizza {

    public String bake();
}
