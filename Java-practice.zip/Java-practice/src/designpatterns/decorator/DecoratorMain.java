package designpatterns.decorator;

public class DecoratorMain {

    public static void main(String[] args) {

        Pizza pizza=new CheezeBurstDecorator(new BasePizza());
        System.out.println(pizza.bake());
    }
}
