package designpatterns.decorator;

public class CheezeBurstDecorator extends PizzaDecorator {

    public CheezeBurstDecorator(Pizza pizza) {
        super(pizza);
    }

    public String bake() {
        return pizza.bake() + addCheese();
    }

    public String addCheese() {
        return "Cheese";
    }
}
