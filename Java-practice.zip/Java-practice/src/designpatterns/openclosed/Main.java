package designpatterns.openclosed;

public class Main {

    public static void main(String[] args) {

        Calculator calc = new Calculator();
        int num = calc.calculate(2, 1, new AddOperation());
        System.out.println(num);
    }
}
