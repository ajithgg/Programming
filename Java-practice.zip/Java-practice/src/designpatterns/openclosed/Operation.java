package designpatterns.openclosed;

public interface Operation {

    public int perform(int num1, int num2);
}
