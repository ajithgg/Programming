package designpatterns.prototype;

public class TwoWheelerVehicle extends Vehicle {

    boolean isElectric;

    public TwoWheelerVehicle(String engine, String model, long price, boolean isElectric) {
        super(engine, model, price);
        this.isElectric = isElectric;
    }

    @Override
    public String toString() {
        return "TwoWheelerVehicle{" +
                "isElectric=" + isElectric +
                '}';
    }
}
