package designpatterns.prototype;

public class PrototypeMain {

    public static void main(String[] args) {

        try {
            Vehicle vehicle = VehicleRegistry.getVehicle("TWO");

            System.out.println(vehicle);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

    }
}
