package designpatterns.prototype;

import java.util.HashMap;
import java.util.Map;

public class VehicleRegistry {

    private static Map<String, Vehicle> regMap = new HashMap<>();

    static {
        regMap.put("TWO", new TwoWheelerVehicle("120", "Honda", 25000, false));
        regMap.put("Four", new FourWheelerVehicle("120", "Honda", 25000, false, false));
    }

    public static Vehicle getVehicle(String vehicle) throws CloneNotSupportedException {
        return regMap.get(vehicle).clone();
    }
}
