package designpatterns.abstractfactory;

public interface Button {
    void paint();
}
