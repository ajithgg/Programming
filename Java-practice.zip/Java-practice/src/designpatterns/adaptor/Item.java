package designpatterns.adaptor;

public interface Item {

    String getItemName();
    String getPrice();
    String getRestaurantName();
}
