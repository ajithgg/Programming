package designpatterns.adaptor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SwiggyStore {

    List<Item> items = new ArrayList<>();

    public void addItems(Item item) {
        items.add(item);
    }

    public void displayItemsInCart(){

        if(null!=items && items.size()>0){

            items.forEach(item -> {

                System.out.println(item.getItemName());
                System.out.println(item.getPrice());
                System.out.println(item.getRestaurantName());
            });
        }

    }
}
