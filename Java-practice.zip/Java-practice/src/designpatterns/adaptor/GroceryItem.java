package designpatterns.adaptor;

public interface GroceryItem {

    String getName();
    String getPrice();
    String getStoreName();
}
