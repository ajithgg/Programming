package designpatterns.adaptor;

public class FoodItem implements Item {

    private String item;
    private String price;
    private String restaurantName;

    public FoodItem(String item, String price, String restaurantName) {
        this.item = item;
        this.price = price;
        this.restaurantName = restaurantName;
    }


    @Override
    public String getItemName() {
        return this.item;
    }

    @Override
    public String getPrice() {
        return this.price;
    }

    @Override
    public String getRestaurantName() {
        return this.restaurantName;
    }
}
