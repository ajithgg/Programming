package designpatterns.adaptor;

public class AdaptorMain {

    public static void main(String[] args) {


        SwiggyStore store = new SwiggyStore();
        store.addItems(new FoodItem("pizza", "200", "Domino's"));
        store.addItems(new GroceryItemAdaptor(new GroceryProduct("Food items", "2000", "Reliance Stores")));


        store.displayItemsInCart();
    }
}
