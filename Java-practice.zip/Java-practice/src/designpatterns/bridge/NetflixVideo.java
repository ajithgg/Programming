package designpatterns.bridge;

public class NetflixVideo extends Video{

    VideoProcessor processor;

    public NetflixVideo(VideoProcessor processor) {
        super(processor);
        this.processor=processor;
    }

    @Override
    public void play(String videoFile) {
        processor.process(videoFile);
    }
}
