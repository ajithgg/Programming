package designpatterns.bridge;

public abstract class Video {

    private VideoProcessor processor;

    public Video(VideoProcessor processor) {
        this.processor = processor;
    }

    public abstract  void play(String videoFile);
}
