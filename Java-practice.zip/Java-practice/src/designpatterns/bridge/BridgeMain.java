package designpatterns.bridge;

public class BridgeMain {

    public static void main(String[] args) {

        Video youtubeVideo=new YoutubeVideo(new HDProcessor());
        youtubeVideo.play("youtube.mp4");

        Video youtubeVideo2=new YoutubeVideo(new UHDProcessor());
        youtubeVideo2.play("youtube.mp4");

    }
}
