package designpatterns.bridge;

public interface VideoProcessor {
    void process(String videoFile);
}
