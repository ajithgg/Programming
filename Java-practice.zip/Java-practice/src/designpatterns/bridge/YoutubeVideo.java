package designpatterns.bridge;

public class YoutubeVideo extends Video{

    VideoProcessor processor;
    public YoutubeVideo(VideoProcessor processor) {
        super(processor);
        this.processor=processor;
    }

    @Override
    public void play(String videoFile) {

        processor.process(videoFile);
    }
}
