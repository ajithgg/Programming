package designpatterns.facade;

public interface Shape {

    void draw();
}
