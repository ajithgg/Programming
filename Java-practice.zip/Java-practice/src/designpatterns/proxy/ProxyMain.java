package designpatterns.proxy;

public class ProxyMain {

    public static void main(String[] args) {

        Image img=new ProxyImage("Test.png");

        img.display();
        //Image img2=new ProxyImage("Test2.png");
        img.display();
    }
}
