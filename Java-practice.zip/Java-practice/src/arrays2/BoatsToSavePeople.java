package arrays2;

import java.util.Arrays;

public class BoatsToSavePeople {

    public static void main(String[] args) {
        System.out.println(numRescueBoats(new int[]{1,3,2},3));

    }

    public static int numRescueBoats(int[] people, int limit) {

        int minBoats=0;
        Arrays.sort(people);
        int start=0;
        int end=people.length-1;

        while (start<=end){

            if(people[start]+people[end]<=limit){

                start++;
            }
            end--;

            minBoats++;
        }



        return minBoats;
    }
}
