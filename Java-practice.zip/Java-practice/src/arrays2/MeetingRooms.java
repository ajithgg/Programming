package arrays2;

import java.util.Arrays;

public class MeetingRooms {

    public static void main(String[] args) {

        // Starting time
        int[] start = { 10, 21, 28 };

        // Finish time
        int[] end = { 20, 25, 30 };
        int meetingRooms=findMeetingRooms(start,end,end.length);
        System.out.println("No of meetings ===> "+meetingRooms);

    }

    public static int findMeetingRooms(int start[], int end[], int n) {

        Arrays.sort(start);
        Arrays.sort(end);
        int meetingRooms = 1;

        int i = 1;
        int j = 0;

        while (i < end.length) {

            if (start[i] > end[j]) {
                meetingRooms++;
            } else {
                j++;
            }

            i++;
        }
        return meetingRooms;

    }
}
