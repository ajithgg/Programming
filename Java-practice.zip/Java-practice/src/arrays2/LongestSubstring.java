package arrays2;

public class LongestSubstring {

    private static int longestSubString(String s) {

        int maxCount = 0;
        char maxChar = 0;
        int length = s.length();
        //int startIdx = 0;

        int i = 0;
        while (i < length - 1) {

            int currentMax = 1;
            //startIdx=i;
            for (int j = i + 1; j < length; j++) {

                if (s.charAt(i) != s.charAt(j)) {
                    i = j;
                    break;
                }
                currentMax++;

                if (maxCount < currentMax) {
                    maxCount = currentMax;
                    maxChar = s.charAt(i);
                    //startIdx = j - i + 1;
                    //startIdx=i;
                }
            }


        }

        System.out.println(maxChar);
        //System.out.println(maxCount);
        System.out.println(maxCount);
        return maxCount;
    }


    public static void main(String[] args) {
        String s = "abbbccda";

        int maxCount = longestSubString(s);
        System.out.println(maxCount);
    }
}
