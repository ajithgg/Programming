package arrays2;

public class MajorityElement2 {

    public static void main(String[] args) {

    }

    public static void majorityElemnt(int[] a){

        int elem1=-1;
        int elem2=-1;
        int count1=0;
        int count2=0;





    }
}
