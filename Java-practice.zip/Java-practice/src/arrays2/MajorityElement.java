package arrays2;

public class MajorityElement {

    public static void main(String[] args) {

        int[] a={2,2,3,3};
        System.out.println(findMajorityElement(a));

    }

    public static int findMajorityElement(int[] a) {

        int element = 0;
        int cnt = 0;

        for (int n : a) {

            if (cnt == 0) {
                element = n;
            }

            if (n == element) cnt++;
            else
                cnt--;
        }


        return element;
    }
}
