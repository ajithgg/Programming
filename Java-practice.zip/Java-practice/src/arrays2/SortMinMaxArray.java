package arrays2;

import java.util.Arrays;
import java.util.Collections;

public class SortMinMaxArray {

    public static void main(String[] args) {

        int[] a = {1, 2, 3, 4, 5, 6};
        int[] finalArr = sortMaxMinArry(a);
        System.out.println("finalArr ========> " + Arrays.toString(finalArr));
    }

    public static int[] sortMaxMinArry(int[] arr) {

        int[] a1 = arr;
        int[] a2 = Arrays.stream(arr).boxed()
                .sorted(Collections.reverseOrder())
                .mapToInt(Integer::intValue)
                .toArray();
        System.out.println("a1 ======> " + Arrays.toString(a1));
        System.out.println("a2 ======> " + Arrays.toString(a2));

        int i = 0;
        int j = arr.length - 1;
        int[] temp = arr.clone();

        int k = 0;
        boolean flag = false;
        while (i <= j) {
            if (!flag) {
                temp[k] = arr[j];
                j--;
            } else {
                temp[k] = arr[i];
                i++;
            }

            flag = !flag;
            k++;
        }


        return temp;
    }
}
