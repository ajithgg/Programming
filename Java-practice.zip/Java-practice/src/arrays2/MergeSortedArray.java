package arrays2;

import java.util.Arrays;

public class MergeSortedArray {

    public static void main(String[] args) {
        int a1[]={1,2,3,0,0,0};
        int a2[]={2,4,5};

        int[] mergedArr=mergeArray(a1,a2);

        System.out.println(Arrays.toString(mergedArr));

    }

    private static int[] mergeArray(int[] a1,int[] a2){

        int[] temp=new int[a1.length];

        int i=0;
        int j=0;

        for(int k=0;k<temp.length;k++){

            if(a1[i]!=0 && a1[i]<a2[j]){
                temp[k]=a1[i];
                i++;
            }else{
                temp[k]=a2[j];
                j++;
            }
        }
        return temp;
    }
}
