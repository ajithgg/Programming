package arrays2;

import java.util.Arrays;

public class RangeAddition {

    public static void main(String[] args) {

        int[][] updates = {
                {1, 3, 2},
                {2, 4, 3},
                {0, 2, -2}
        };
        //int[] res = rangeAdditionBrute(5, updates);
        int[] res = rangeAddition(5, updates);
        System.out.println(Arrays.toString(res));
    }

    public static int[] rangeAddition(int length, int[][] updates) {
        int[] results = new int[length];
        Arrays.fill(results, 0);

        for (int[] a : updates) {
            int[] elements = a;
            int startIndex = elements[0];
            int endIndex = elements[1];
            int incrementor = elements[2];

            results[startIndex] = incrementor;
            if (endIndex + 1 < length)
                results[endIndex + 1] = -incrementor;
        }

        int sum = 0;
        for (int k = 0; k < results.length; k++) {
            sum += results[k];
            results[k] = sum;
        }
        return results;
    }

    public static int[] rangeAdditionBrute(int length, int[][] updates) {

        int[] results = new int[length];
        Arrays.fill(results, 0);
        for (int[] a : updates) {
            int[] elements = a;
            int startIndex = elements[0];
            int endIndex = elements[1];
            int incrementor = elements[2];

            for (int i = startIndex; i <= endIndex; i++) {
                results[i] += incrementor;
            }
        }
        return results;
    }
}
