public class BuySellStock {

    public static void main(String[] args) {

        int[] a={7,1,5,3,6,4};
        int maxProfit=maxProfit(a);
        System.out.println(maxProfit);

    }

    private static int maxProfit(int[] a) {
        int i = 0, j = 0, maxProfit = Integer.MIN_VALUE;

        for (i = 0; i < a.length; i++) {
            for (j = i + 1; j < a.length; j++) {
                if (a[i] < a[j]) {
                    maxProfit = Math.max(maxProfit, a[j] - a[i]);
                }
            }
        }
        return maxProfit;
    }
}
