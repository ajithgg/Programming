package recursion;

import java.util.ArrayList;
import java.util.List;

public class LinearSearch {

    public static void main(String[] args) {

        int[] arr = {3, 2, 1, 18, 9};
        int index = linearSearch(arr, 9, 0);
        System.out.println(index);

        int[] arr2={3,2,1,18,4,4,9};
        List<Integer> ls=findAllIndex(arr2,4,0,new ArrayList<>());
        System.out.println(ls);

        List<Integer> ls2=findAllIndex2(arr2,4,0);
        System.out.println(ls2);
    }

    static List<Integer> findAllIndex(int[] arr, int target, int index, List<Integer> ls) {

        if (index == arr.length)
            return ls;

        if (arr[index] == target)
            ls.add(index);

        return findAllIndex(arr, target, index + 1, ls);

    }

    static List<Integer> findAllIndex2(int[] arr, int target, int index) {

        List<Integer> ls2 = new ArrayList<>();
        if (index == arr.length)
            return ls2;

        if (arr[index] == target)
            ls2.add(index);

        List<Integer> ansFromBelow = findAllIndex2(arr, target, index + 1);

        ls2.addAll(ansFromBelow);

        return ls2;
    }

    static int linearSearch(int[] arr, int value, int index) {

        if (index == arr.length)
            return -1;

        if (arr[index] == value)
            return index;
        else
            return linearSearch(arr, value, index + 1);
    }
}
