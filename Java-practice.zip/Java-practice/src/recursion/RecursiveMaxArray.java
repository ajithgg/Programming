package recursion;

public class RecursiveMaxArray {

    public static void main(String[] args) {
        //printRecursive(5);

        System.out.print(fiboRecursion(5));
    }

    private static int fiboRecursion(int n) {
        if (n == 0) return 0;
        if (n == 1 || n == 2) return 1;
        return fiboRecursion(n - 1) + fiboRecursion(n - 2);
    }

    private static void printRecursive(int n){

        if(n==0) return;

        printRecursive(n-1);
        System.out.println(n);

    }
}
