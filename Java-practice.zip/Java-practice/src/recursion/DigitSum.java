package recursion;

public class DigitSum {

    public static void main(String[] args) {

        digitSum(1352);
        System.out.println(digitSumRecursive(1352));

    }

    static int digitSumRecursive(int n) {
        if (n == 0) {
            return 0;
        }
        return n % 10 + digitSumRecursive(n / 10);
    }

    static int digitSum(int n) {

        int sum = 0;
        int r = 0;
        while (n > 0) {
            r = n % 10;
            sum += r;
            n = n / 10;
        }
        System.out.println("Sum of Digits " + sum);
        return sum;
    }
}
