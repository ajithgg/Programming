package recursion;

public class Sorted {

    public static void main(String[] args) {
        int[] arr={1,2,3,5,8};
        boolean isSorted=sorted(arr,0);

        System.out.println(isSorted);
    }

    static boolean sorted(int[] arr, int index) {

        if (index == arr.length - 1)
            return true;

        return arr[index] < arr[index + 1] && sorted(arr, index + 1);
    }
}
