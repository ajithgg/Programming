package recursion;

public class NumbersExample {

    public static void main(String[] args) {

        print(1);
    }

    public static void print(int n){
        System.out.println(n);
        if (n < 5)
            print(n+1);
        else
            return;
    }

    private static void print1(int i) {
        System.out.println(i);
        print2(2);
    }

    private static void print2(int i) {
        System.out.println(i);
        print3(3);
    }

    private static void print3(int i) {
        System.out.println(i);
        print4(4);
    }

    private static void print4(int i) {
        System.out.println(i);
    }
}
