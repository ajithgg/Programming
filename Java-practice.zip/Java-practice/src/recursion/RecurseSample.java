package recursion;

public class RecurseSample {

    public static void main(String[] args) {

        print(5);
        System.out.println();
        print1(5);
    }


    private static void print(int n) {
        if (n == 0) {
            return;
        }
        System.out.print(n+" ==> ");
        print(n - 1);
    }

    private static void print1(int n) {
        if (n == 0) {
            return;
        }

        print1(n - 1);
        System.out.print(n+" ==> ");
    }
}
